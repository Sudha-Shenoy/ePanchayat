<?php
session_start();
require 'db.php';

if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

$app_id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("DELETE FROM scheme_applications WHERE id = ? AND user_id = ? AND status = 'pending'");
$stmt->bind_param("ii", $app_id, $user_id);

$deleted = $stmt->execute();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Delete Application</title>
<style>
  body {
    font-family: Arial, sans-serif;
    
    background-size: cover;
    color: #fff;
    margin: 0; padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  .message-box {
    background: rgba(0,0,0,0.75);
    padding: 30px 40px;
    border-radius: 10px;
    box-shadow: 0 0 20px #000;
    text-align: center;
    max-width: 400px;
  }
  h2 {
    margin-bottom: 20px;
  }
  a {
    color: #00c3ff;
    text-decoration: none;
    font-weight: bold;
    font-size: 18px;
  }
  a:hover {
    text-decoration: underline;
  }
</style>
</head>
<body>
  <div class="message-box">
    <?php if ($deleted): ?>
      <h2>Application deleted successfully.</h2>
      <a href="apply_schemes.php">Back to Schemes</a>
    <?php else: ?>
      <h2>Error deleting application.</h2>
      <a href="apply_schemes.php">Try Again</a>
    <?php endif; ?>
  </div>
</body>
</html>
