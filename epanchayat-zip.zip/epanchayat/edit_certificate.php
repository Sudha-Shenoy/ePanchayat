<?php
// Include database connection
include('db.php');
session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];  // Get the logged-in user's ID

// Check if request_id is passed
if(!isset($_GET['request_id'])) {
    echo "Request ID is missing.";
    exit();
}

$request_id = $_GET['request_id'];

// Fetch current certificate request details from the database
$query = $conn->prepare("SELECT * FROM certificate_requests WHERE id = ? AND user_id = ?");
$query->bind_param("ii", $request_id, $user_id);
$query->execute();
$result = $query->get_result();
$row = $result->fetch_assoc();

if(!$row) {
    echo "Certificate request not found.";
    exit();
}

// Handle form submission to update the certificate request
if(isset($_POST['update_request'])) {
    $certificate_type = $_POST['certificate_type'];
    $purpose = $_POST['purpose'];
    $file = $_FILES['document'];

    // Handle file upload if new document is provided
    if($file['error'] == 0) {
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $file_path = 'uploads/' . time() . '_' . basename($file_name);
        move_uploaded_file($file_tmp, $file_path);
        
        // Update document in submitted_documents table
        $query_doc = $conn->prepare("UPDATE submitted_documents SET file_path = ?, status = 'Pending', submitted_at = NOW() WHERE user_id = ? AND doc_type = 'Certificate' AND id = ?");
        $query_doc->bind_param("sii", $file_path, $user_id, $request_id);
        $query_doc->execute();
    }

    // Update certificate request details
    $query_update = $conn->prepare("UPDATE certificate_requests SET certificate_type = ?, purpose = ?, request_date = NOW() WHERE id = ?");
    $query_update->bind_param("ssi", $certificate_type, $purpose, $request_id);
    $query_update->execute();

    echo "<p style='color:#0f0; text-align:center;'>Certificate request updated successfully.</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit Certificate Request</title>
<style>
  /* Background */
  body {
    margin: 0; padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    color: #333;
  }

  /* Form Container */
  .container {
    background: rgba(255, 255, 255, 0.95);
    padding: 30px 40px;
    border-radius: 10px;
    width: 400px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
  }

  h1 {
    text-align: center;
    margin-bottom: 25px;
    color: #007acc;
  }

  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
  }

  input[type="text"], input[type="file"] {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    box-sizing: border-box;
  }

  button {
    width: 100%;
    padding: 12px;
    background-color: #007acc;
    border: none;
    border-radius: 6px;
    color: white;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  button:hover {
    background-color: #005fa3;
  }

  a {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #007acc;
    text-decoration: none;
    font-weight: 600;
  }

  a:hover {
    text-decoration: underline;
  }

  p.success {
    text-align: center;
    font-weight: 700;
    color: #28a745;
    margin-bottom: 15px;
  }
</style>
</head>
<body>
  <div class="container">
    <h1>Edit Certificate Request</h1>

    <!-- Form to edit certificate request -->
    <form method="POST" enctype="multipart/form-data">
      <label for="certificate_type">Certificate Type:</label>
      <input type="text" id="certificate_type" name="certificate_type" value="<?= htmlspecialchars($row['certificate_type']) ?>" required>

      <label for="purpose">Purpose:</label>
      <input type="text" id="purpose" name="purpose" value="<?= htmlspecialchars($row['purpose']) ?>" required>

      <label for="document">Upload New Document (optional):</label>
      <input type="file" id="document" name="document" accept=".pdf,.doc,.docx,.jpg,.png">

      <button type="submit" name="update_request">Update Request</button>
    </form>
    
    <a href="request_certificates.php">← Back to your requests</a>
  </div>
</body>
</html>
