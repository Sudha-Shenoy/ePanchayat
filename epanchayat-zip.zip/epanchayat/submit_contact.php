<?php
// submit_contact.php
$message = '';
$name = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $message = htmlspecialchars($_POST['message']);
    // Here you would save to DB or send email

    $response = "Thank you, <strong>$name</strong>. Your message has been received!";
} else {
    $response = "Invalid request.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Contact Submission</title>
<style>
  body {
    margin: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:
      linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),
     
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #333;
  }
  .container {
    background: #fff;
    padding: 40px 50px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    max-width: 500px;
    text-align: center;
  }
  p {
    font-size: 1.2rem;
    margin-bottom: 25px;
  }
  a {
    color: #2980b9;
    text-decoration: none;
    font-weight: 600;
    font-size: 1rem;
  }
  a:hover {
    text-decoration: underline;
  }
</style>
</head>
<body>
  <div class="container">
    <p><?= $response ?></p>
    <a href="index.php">← Back to Home</a>
  </div>
</body>
</html>
