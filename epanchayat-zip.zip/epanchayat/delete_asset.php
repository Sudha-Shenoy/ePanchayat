<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php");
    exit();
}

include 'db.php';

// Validate and sanitize ID parameter
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    die("Invalid asset ID.");
}

$id = (int)$_GET['id'];

// Get file path securely using prepared statements
$stmt = $conn->prepare("SELECT file_path FROM assets WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row && file_exists($row['file_path'])) {
    unlink($row['file_path']); // delete file from server
}

// Delete record from database
$stmt_del = $conn->prepare("DELETE FROM assets WHERE id = ?");
$stmt_del->bind_param("i", $id);
$stmt_del->execute();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Delete Asset</title>
    <style>
        body {
            margin: 0; padding: 0;
            
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .message-box {
            background: rgba(0,0,0,0.7);
            padding: 30px 40px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 15px #000;
        }
        h2 {
            margin-bottom: 20px;
        }
        a {
            color: #00c3ff;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="message-box">
        <h2>Asset Deleted Successfully</h2>
        <p>The asset has been removed from the system.</p>
        <p><a href="view_assets.php">Return to Assets List</a></p>
    </div>
</body>
</html>
