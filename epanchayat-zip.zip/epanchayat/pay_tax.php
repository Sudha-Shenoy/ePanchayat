<?php
session_start();
include 'db.php';

if (!isset($_GET['tax_id'])) {
    echo "Invalid request.";
    exit;
}

$tax_id = $_GET['tax_id'];
$user_id = $_SESSION['user_id'];

// Fetch tax info for the logged-in user
$sql = "SELECT utd.id, utd.amount_due, tt.name AS tax_name, utd.tax_type_id
        FROM user_tax_details utd
        JOIN tax_types tt ON utd.tax_type_id = tt.id
        WHERE utd.id = ? AND utd.user_id = ? AND utd.status = 'unpaid'";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $tax_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$tax = $result->fetch_assoc();

if (!$tax) {
    echo "Tax not found or already paid.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Pay Tax - <?= htmlspecialchars($tax['tax_name']) ?></title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

  body {
    margin: 0;
    font-family: 'Montserrat', sans-serif;
    background:
      linear-gradient(rgba(255,255,255,0.8), rgba(255,255,255,0.8)),
      
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #333;
  }

  .payment-container {
    background: #fff;
    padding: 30px 40px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    width: 350px;
    text-align: center;
  }

  h2 {
    margin-bottom: 20px;
    color: #2c3e50;
  }

  p {
    font-size: 1.2rem;
    margin-bottom: 20px;
  }

  label {
    display: block;
    font-weight: 600;
    margin-bottom: 8px;
    text-align: left;
  }

  select {
    width: 100%;
    padding: 10px 12px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 1rem;
    margin-bottom: 25px;
  }

  button {
    background-color: #2980b9;
    color: white;
    padding: 12px 0;
    width: 100%;
    border: none;
    border-radius: 6px;
    font-size: 1.1rem;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  button:hover {
    background-color: #1c5980;
  }
</style>
</head>
<body>

<div class="payment-container">
  <h2>Pay Tax: <?= htmlspecialchars($tax['tax_name']) ?></h2>
  <form method="post" action="pay_tax_process.php">
    <input type="hidden" name="tax_id" value="<?= $tax['id'] ?>">
    <input type="hidden" name="tax_type_id" value="<?= $tax['tax_type_id'] ?>">
    <input type="hidden" name="amount" value="<?= $tax['amount_due'] ?>">

    <p>Amount Due: <strong>₹<?= number_format($tax['amount_due'], 2) ?></strong></p>

    <label for="method">Payment Method:</label>
    <select name="method" id="method" required>
      <option value="" disabled selected>Select a method</option>
      <option value="UPI">UPI</option>
      <option value="Credit Card">Credit Card</option>
      <option value="Bank Transfer">Bank Transfer</option>
    </select>

    <button type="submit">Confirm Payment</button>
  </form>
</div>

</body>
</html>
