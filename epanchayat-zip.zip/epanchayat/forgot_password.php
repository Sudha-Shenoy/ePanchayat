<?php
include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Forgot Password</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');

    body.forgot-page {
      margin: 0;
      padding: 0;
      font-family: 'Open Sans', sans-serif;
      height: 100vh;
      background: url('assets/default-bg.jpg') no-repeat center center fixed;
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #333;
    }

    .container {
      background: rgba(255, 255, 255, 0.92);
      padding: 40px 50px;
      border-radius: 12px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.2);
      width: 350px;
      text-align: center;
    }

    h2 {
      margin-bottom: 30px;
      color: #2c3e50;
      font-weight: 700;
      letter-spacing: 1.1px;
    }

    input[type="text"] {
      width: 100%;
      padding: 12px 15px;
      margin: 10px 0 20px 0;
      border-radius: 8px;
      border: 1.8px solid #bbb;
      font-size: 1em;
      transition: border-color 0.3s ease;
    }

    input[type="text"]:focus {
      border-color: #2980b9;
      outline: none;
    }

    input[type="submit"] {
      width: 100%;
      padding: 12px 0;
      font-size: 1.1em;
      font-weight: 700;
      border: none;
      border-radius: 8px;
      background-color: #2980b9;
      color: white;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    input[type="submit"]:hover {
      background-color: #1c5980;
    }

    p {
      margin-top: 20px;
      font-size: 0.9em;
    }

    p a {
      color: #2980b9;
      text-decoration: none;
      font-weight: 600;
    }

    p a:hover {
      text-decoration: underline;
    }

    /* Messages */
    .message {
      margin-top: 15px;
      font-size: 1em;
      font-weight: 600;
    }

    .success {
      color: #27ae60;
    }

    .error {
      color: #c0392b;
    }
  </style>
</head>
<body class="forgot-page">
  <div class="container">
    <h2>Forgot Password</h2>
    <form method="POST" action="">
      <input type="text" name="username" placeholder="Enter your username" required>
      <input type="text" name="mobile" placeholder="Enter your mobile number" required>
      <input type="submit" name="recover" value="Recover Password">
    </form>

    <?php
    if (isset($_POST['recover'])) {
      $username = mysqli_real_escape_string($conn, $_POST['username']);
      $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);

      $query = "SELECT * FROM users WHERE username='$username' AND mobile='$mobile'";
      $result = mysqli_query($conn, $query);

      if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        echo "<p class='message success'>Your password is: <strong>" . htmlspecialchars($user['PASSWORD']) . "</strong></p>";
      } else {
        echo "<p class='message error'>No user found with the provided details.</p>";
      }
    }
    ?>
    <p><a href="login.php">← Back to Login</a></p>
  </div>
</body>
</html>
