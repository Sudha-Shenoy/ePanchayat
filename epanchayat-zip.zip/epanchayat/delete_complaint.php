<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'], $_POST['id'])) {
    $id = (int)$_POST['id'];

    // Optional: check if complaint exists before deleting (not shown here)

    $stmt = $conn->prepare("DELETE FROM complaints WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: manage_complaints.php");
    exit();
} else if (!isset($_POST['id']) && !isset($_GET['id'])) {
    die("No complaint ID provided.");
} else {
    // Get the complaint ID either from POST or GET for confirmation
    $id = isset($_POST['id']) ? (int)$_POST['id'] : (int)$_GET['id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Delete Complaint Confirmation</title>
    <style>
        body {
            margin: 0; padding: 0;
           
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .confirm-box {
            background: rgba(0,0,0,0.75);
            padding: 30px 40px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 0 15px #000;
            max-width: 400px;
        }
        h2 {
            margin-bottom: 20px;
        }
        button {
            background-color: #ff4d4d;
            border: none;
            padding: 10px 20px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            margin: 0 10px;
        }
        button:hover {
            background-color: #e60000;
        }
        a.cancel-link {
            color: #00c3ff;
            text-decoration: none;
            font-weight: bold;
            font-size: 16px;
            margin-left: 10px;
        }
        a.cancel-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="confirm-box">
        <h2>Are you sure you want to delete this complaint?</h2>
        <form method="POST" action="">
            <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">
            <button type="submit" name="delete">Yes, Delete</button>
            <a href="manage_complaints.php" class="cancel-link">Cancel</a>
        </form>
    </div>
</body>
</html>
