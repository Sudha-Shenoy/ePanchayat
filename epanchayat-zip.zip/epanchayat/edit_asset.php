<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php");
    exit();
}
include 'db.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM assets WHERE id=$id");
$row = $result->fetch_assoc();

if (isset($_POST['update'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $file_path = $row['file_path']; // default: keep old file

    if ($_FILES['new_file']['name']) {
        $file = $_FILES['new_file'];
        $file_name = basename($file['name']);
        $target_dir = "uploads/";
        $new_path = $target_dir . time() . "_" . $file_name;
        $file_type = strtolower(pathinfo($new_path, PATHINFO_EXTENSION));
        $allowed = ['pdf', 'docx', 'jpg', 'png'];

        if (!in_array($file_type, $allowed)) {
            echo "Invalid file type.";
            exit();
        }

        if (move_uploaded_file($file['tmp_name'], $new_path)) {
            if (file_exists($row['file_path'])) {
                unlink($row['file_path']); // delete old file
            }
            $file_path = $new_path; // update to new path
        } else {
            echo "File upload failed.";
            exit();
        }
    }

    $stmt = $conn->prepare("UPDATE assets SET title=?, description=?, file_path=? WHERE id=?");
    $stmt->bind_param("sssi", $title, $description, $file_path, $id);
    $stmt->execute();

    header("Location: view_assets.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Edit Asset</title>
<style>
  /* Background */
  body {
    margin: 0; padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    
    background-size: cover;
    color: #fff;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  /* Container */
  .container {
    background: rgb(204, 199, 199);
    padding: 30px 40px;
    border-radius: 10px;
    width: 450px;
    box-shadow: 0 0 15px #000;
  }

  h2 {
    margin-top: 0;
    margin-bottom: 25px;
    text-align: center;
    font-weight: 700;
    letter-spacing: 1.2px;
  }

  label {
    display: block;
    margin-bottom: 6px;
    font-weight: 600;
  }

  input[type="text"], textarea {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 20px;
    border: none;
    border-radius: 5px;
    font-size: 14px;
  }

  textarea {
    resize: vertical;
    min-height: 80px;
  }

  input[type="file"] {
    margin-bottom: 20px;
  }

  input[type="submit"] {
    background-color: #00c3ff;
    border: none;
    padding: 12px;
    width: 100%;
    border-radius: 6px;
    color: #000;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  input[type="submit"]:hover {
    background-color: #0099cc;
    color: #fff;
  }

  a {
    display: inline-block;
    margin-top: 15px;
    color: #00c3ff;
    text-decoration: none;
    font-weight: 600;
  }

  a:hover {
    text-decoration: underline;
  }

  a[target="_blank"] {
    color: #f0a500;
  }
</style>
</head>
<body class="staff">
  <div class="container">
    <h2>Edit Uploaded Asset</h2>
    <form method="POST" enctype="multipart/form-data">
      <label for="title">Title:</label>
      <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($row['title']); ?>" required>

      <label for="description">Description:</label>
      <textarea id="description" name="description"><?php echo htmlspecialchars($row['description']); ?></textarea>

      <label>Current File:</label>
      <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank" rel="noopener noreferrer">View Existing File</a>

      <label for="new_file">Replace File (optional):</label>
      <input type="file" id="new_file" name="new_file" accept=".pdf,.docx,.jpg,.png">

      <input type="submit" name="update" value="Update Asset">
    </form>

    <a href="view_assets.php">← Back</a>
  </div>
</body>
</html>
