<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "epanchayat");

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM users WHERE id=$id");
    header("Location: manage_users.php");
    exit();
}

$result = $conn->query("SELECT * FROM users");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Manage Users - Admin</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

    body {
        margin: 0;
        font-family: 'Roboto', sans-serif;
        background:
          linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
          url('assets/default-bg.jpeg');
        background-size: cover;
        color: #f5f5f5;
        min-height: 100vh;
        padding: 40px 20px;
    }

    .container {
        max-width: 900px;
        margin: 0 auto;
        background: rgba(255, 255, 255, 0.95);
        color: #333;
        border-radius: 10px;
        padding: 30px 40px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.3);
    }

    h2 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: 700;
        color: #2c3e50;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 1rem;
    }

    th, td {
        padding: 12px 15px;
        border: 1px solid #ccc;
        text-align: left;
    }

    th {
        background-color: #34495e;
        color: #ecf0f1;
        font-weight: 600;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:hover {
        background-color: #d1e7fd;
    }

    a {
        color: #2980b9;
        font-weight: 600;
        text-decoration: none;
        margin-right: 10px;
    }
    a:hover {
        text-decoration: underline;
    }

    .back-link {
        display: block;
        margin-top: 30px;
        font-weight: 600;
        text-align: center;
        color: #2980b9;
        text-decoration: none;
    }
    .back-link:hover {
        text-decoration: underline;
    }

    /* Responsive table for smaller screens */
    @media (max-width: 768px) {
        table, thead, tbody, th, td, tr {
            display: block;
        }
        thead tr {
            display: none;
        }
        tr {
            margin-bottom: 20px;
            background: #fff;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        td {
            padding-left: 50%;
            position: relative;
            text-align: left;
            border: none;
            color: #34495e;
        }
        td:before {
            content: attr(data-label);
            position: absolute;
            left: 15px;
            top: 12px;
            font-weight: 700;
            color: #34495e;
            white-space: nowrap;
        }
    }
</style>
</head>
<body>
<div class="container">
    <h2>Manage Users</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td data-label="ID"><?= htmlspecialchars($row['id']); ?></td>
                <td data-label="Username"><?= htmlspecialchars($row['username']); ?></td>
                <td data-label="Role"><?= htmlspecialchars($row['role']); ?></td>
                <td data-label="Actions">
                    <a href="edit_user.php?id=<?= $row['id']; ?>">Edit</a> | 
                    <a href="manage_users.php?delete=<?= $row['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>
</div>
</body>
</html>
