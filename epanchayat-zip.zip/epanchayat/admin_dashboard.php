
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            background: url('assets/admin-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 20px;
        }
        .content-wrapper {
            background: rgba(0, 0, 0, 0.6);
            padding: 20px;
            border-radius: 10px;
            max-width: 800px;
            margin: 40px auto;
        }
    </style>
</head>
<body>
    <div class="content-wrapper">
        <?php

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - ePanchayat</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="admin-dashboard">
  <div class="container">
    <h2>Welcome, Admin <?php echo $_SESSION['username']; ?>!</h2>
    <ul>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="view_scheme_applications.php">Process Scheme Applications</a></li>
        <li><a href="manage_services.php">Manage Services & Schemes</a></li>
        <li><a href="upload_assets.php">Upload Village Assets</a></li>
        <li><a href="manage_complaints.php">Manage Complaints</a></li>
        <li><a href="publish_notice.php">Publish Notices</a></li>
        <li><a href="view_user_payments.php">Handle Tax Payments</a></li>
        <li><a href="manage_feedback.php">Manage Feedback</a></li>
        <li><a href="manage_reports.php">Manage Reports</a></li>
        <li><a href="logout.php" style="color: red;">Logout</a></li>
    </ul>
  </div>
</body>
</html>
    </div>
</body>
</html>

