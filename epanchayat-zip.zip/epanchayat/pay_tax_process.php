<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tax_id = $_POST['tax_id'];
    $tax_type_id = $_POST['tax_type_id'];
    $amount = $_POST['amount'];
    $method = $_POST['method'];
    $user_id = $_SESSION['user_id'];

    // Generate receipt number
    $receipt_no = 'RPT' . date("Ymd") . '-' . rand(1000, 9999);

    // Insert into tax_payments
    $insert = "INSERT INTO tax_payments (user_id, tax_type_id, amount_paid, method, receipt_no) 
               VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insert);
    $stmt->bind_param("iidss", $user_id, $tax_type_id, $amount, $method, $receipt_no);
    $stmt->execute();

    // Update user_tax_details as paid
    $update = "UPDATE user_tax_details SET status = 'paid' WHERE id = ?";
    $stmt2 = $conn->prepare($update);
    $stmt2->bind_param("i", $tax_id);
    $stmt2->execute();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Success</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap');
        body {
            margin: 0;
            font-family: 'Montserrat', sans-serif;
            background:
                linear-gradient(rgba(255,255,255,0.85), rgba(255,255,255,0.85)),
               
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #2c3e50;
        }

        .success-container {
            background: #fff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            text-align: center;
        }

        h3 {
            color: #27ae60;
            font-size: 1.8rem;
            margin-bottom: 20px;
        }

        .receipt {
            font-size: 1.2rem;
            margin-bottom: 25px;
        }

        a {
            text-decoration: none;
            color: #fff;
            background: #2980b9;
            padding: 10px 20px;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        a:hover {
            background: #1f6391;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <h3>Payment Successful!</h3>
        <div class="receipt">
            Receipt No: <strong><?= htmlspecialchars($receipt_no) ?></strong><br>
            Amount Paid: ₹<?= number_format($amount, 2) ?><br>
            Payment Method: <?= htmlspecialchars($method) ?>
        </div>
        <a href="view_tax_details.php">Back to Tax Dashboard</a>
    </div>
</body>
</html>
<?php
} else {
    echo "Invalid access.";
}
?>
