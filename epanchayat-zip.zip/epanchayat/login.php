<?php 
include 'db.php'; 
session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">
  <div class="container">
    <h2>Login</h2>
    
    <!-- Show error if any -->
    <?php
    if (isset($_POST['login'])) {
      if (
        empty($_POST['username']) ||
        empty($_POST['password']) ||
        empty($_POST['role']) ||
        empty($_POST['village'])
      ) {
        echo "<p style='color:red;'>All fields are required.</p>";
      } else {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $role = mysqli_real_escape_string($conn, $_POST['role']);
        $village = strtolower(trim($_POST['village']));

        if ($village !== 'abc') {
          echo "<p style='color:red;'>Only residents of abc village can login.</p>";
        } else {
          $sql = "SELECT * FROM users WHERE username='$username' AND PASSWORD='$password' AND role='$role' AND LOWER(village)='$village'";
          $result = mysqli_query($conn, $sql);

          if (!$result) {
            echo "<p style='color:red;'>Database error: " . mysqli_error($conn) . "</p>";
          } elseif (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            if ($role == 'admin') {
              header("Location: admin_dashboard.php");
            } elseif ($role == 'staff') {
              header("Location: staff_dashboard.php");
            } else {
              header("Location: user_dashboard.php");
            }
            exit();
          } else {
            echo "<p style='color:red;'>Invalid credentials or village mismatch.</p>";
          }
        }
      }
    }
    ?>

    <!-- The form always shows -->
    <form method="POST" action="">
      <input type="text" name="username" placeholder="Username" required><br>
      <input type="password" name="password" placeholder="Password" required><br>
      <select name="role" required>
        <option value="">Select Role</option>
        <option value="user">User</option>
        <option value="admin">Admin</option>
        <option value="staff">Staff</option>
      </select><br>
      <input type="text" name="village" placeholder="Enter your village name" required><br><br>
      <input type="submit" name="login" value="Login">
      <p><a href="forgot_password.php">Forgot Password?</a></p>
    </form>
    <a href="index.php">Back</a>
  </div>

</body>
</html>
