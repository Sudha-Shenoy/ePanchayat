<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

include("db.php");

// Get ID from URL
if (!isset($_GET['id'])) {
    echo "No scheme selected.";
    exit();
}

$scheme_id = $_GET['id'];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $eligibility = $_POST['eligibility'];
    $last_date = $_POST['last_date'];
    $status = $_POST['status'];

    $sql = "UPDATE schemes SET 
                name = ?, 
                description = ?, 
                eligibility = ?, 
                last_date = ?, 
                status = ? 
            WHERE id = ?";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssi", $name, $description, $eligibility, $last_date, $status, $scheme_id);
    mysqli_stmt_execute($stmt);

    header("Location: manage_services.php");
    exit();
}

// Fetch existing scheme details
$result = mysqli_query($conn, "SELECT * FROM schemes WHERE id = $scheme_id");
if (mysqli_num_rows($result) == 0) {
    echo "Scheme not found.";
    exit();
}

$scheme = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Scheme</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
            
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #222;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.25);
            max-width: 600px;
            width: 100%;
        }

        h2 {
            margin-bottom: 25px;
            color: #0b3d91;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        input[type="text"], input[type="date"], textarea, select {
            width: 100%;
            padding: 10px 14px;
            margin-bottom: 20px;
            font-size: 16px;
            border: 1.8px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            resize: vertical;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="date"]:focus, textarea:focus, select:focus {
            border-color: #0b3d91;
            outline: none;
        }

        textarea {
            min-height: 100px;
        }

        button {
            width: 100%;
            background-color: #0b3d91;
            color: white;
            font-weight: 700;
            font-size: 18px;
            padding: 14px 0;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #06306a;
        }

        a {
            display: block;
            margin-top: 20px;
            text-align: center;
            font-weight: 600;
            color: #0b3d91;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Scheme</h2>

        <form method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($scheme['name']) ?>" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?= htmlspecialchars($scheme['description']) ?></textarea>

            <label for="eligibility">Eligibility:</label>
            <textarea id="eligibility" name="eligibility" required><?= htmlspecialchars($scheme['eligibility']) ?></textarea>

            <label for="last_date">Last Date:</label>
            <input type="date" id="last_date" name="last_date" value="<?= $scheme['last_date'] ?>" required>

            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="active" <?= $scheme['status'] == 'active' ? 'selected' : '' ?>>Active</option>
                <option value="inactive" <?= $scheme['status'] == 'inactive' ? 'selected' : '' ?>>Inactive</option>
            </select>

            <button type="submit">Update</button>
        </form>

        <a href="manage_services.php">← Back to Dashboard</a>
    </div>
</body>
</html>
