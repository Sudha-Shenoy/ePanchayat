<?php
session_start();
if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $scheme_name = $_POST['scheme_name'];
    $details = $_POST['details'];
    $documents = null;

    $query = "INSERT INTO scheme_applications (user_id, scheme_name, details, documents, status, submitted_at) 
              VALUES (?, ?, ?, ?, 'pending', NOW())";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("isss", $user_id, $scheme_name, $details, $documents);

    if ($stmt->execute()) {
        $message = "Application submitted successfully!";
    } else {
        $message = "Error submitting application: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Submit Scheme Application</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');

  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background:
      linear-gradient(rgba(255,255,255,0.85), rgba(255,255,255,0.85)),
      
    background-size: cover;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #2c3e50;
  }

  .container {
    background: white;
    padding: 35px 45px;
    border-radius: 15px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    max-width: 500px;
    width: 90%;
    text-align: center;
  }

  h2 {
    margin-bottom: 25px;
  }

  p.message {
    font-size: 1.2rem;
    margin-bottom: 20px;
    color: #27ae60;
  }
  p.message.error {
    color: #e74c3c;
  }

  a {
    display: inline-block;
    margin: 10px 15px 0 15px;
    padding: 10px 20px;
    background-color: #2980b9;
    color: white;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: background-color 0.3s ease;
  }
  a:hover {
    background-color: #1c5980;
  }
</style>
</head>
<body>
  <div class="container">
    <h2>Scheme Application</h2>

    <?php if (isset($message)): ?>
      <p class="message <?= strpos($message, 'Error') === 0 ? 'error' : '' ?>"><?= htmlspecialchars($message) ?></p>
      <a href="apply_schemes.php">Apply Another</a>
      <a href="user_dashboard.php">Dashboard</a>
    <?php else: ?>
      <p>No submission detected.</p>
      <a href="apply_schemes.php">Back to Apply</a>
    <?php endif; ?>
  </div>
</body>
</html>
