<?php
// Include database connection
include('db.php');

// Fetch active notices from the database
$query = $conn->prepare("SELECT * FROM notices WHERE status = 'active' ORDER BY publish_date DESC");
$query->execute();
$result = $query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Notices</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            
            background-size: cover;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background-color: rgba(255, 255, 255, 0.96);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.3);
        }

        h1 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid #aaa;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #34495e;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f4f4f4;
        }

        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #2980b9;
            font-weight: bold;
        }

        a:hover {
            color: #d35400;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Notices</h1>

        <?php if ($result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Publish Date</th>
                </tr>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td><?php echo htmlspecialchars($row['publish_date']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No active notices available at the moment.</p>
        <?php endif; ?>

        <a href="user_dashboard.php">← Back to Dashboard</a>
    </div>
</body>
</html>
