<?php
session_start();
if ($_SESSION['role'] !== 'staff' && $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
include 'db.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doc_id = $_POST['doc_id'];
    $status = $_POST['status'];
    $remarks = $_POST['remarks'];
    $cert_id = $_POST['certificate_request_id'];

    // Update document status and remarks
    $stmt = $conn->prepare("UPDATE submitted_documents SET status = ?, remarks = ? WHERE id = ?");
    $stmt->bind_param("ssi", $status, $remarks, $doc_id);
    $stmt->execute();
    $stmt->close();

    // Update certificate status if verified
    if ($status === "Verified") {
        $update = $conn->prepare("UPDATE certificate_requests SET status = 'Approved' WHERE id = ?");
        $update->bind_param("i", $cert_id);
        $update->execute();
        $update->close();
    }

    // If the certificate is approved and the "Issued" button is clicked, mark it as issued
    if (isset($_POST['issue_certificate'])) {
        $updateIssued = $conn->prepare("UPDATE certificate_requests SET issued = 1 WHERE id = ?");
        $updateIssued->bind_param("i", $cert_id);
        $updateIssued->execute();
        $updateIssued->close();
    }
}

// Fetch all certificate requests with submitted documents
$sql = "SELECT cr.id AS certificate_request_id, cr.user_id, cr.certificate_type, cr.purpose, cr.status AS cert_status, cr.issued,
               sd.id AS doc_id, sd.file_path, sd.status, sd.remarks
        FROM certificate_requests cr
        LEFT JOIN submitted_documents sd ON cr.id = sd.certificate_request_id
        ORDER BY cr.request_date DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Issue Certificates</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

        body {
            font-family: 'Montserrat', sans-serif;
            margin: 0; padding: 0;
            background:
              linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
              
            background-size: cover;
            color: #f0f0f0;
        }

        .container {
            max-width: 1100px;
            margin: 40px auto;
            background-color: rgba(255, 255, 255, 0.95);
            color: #222;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: 700;
            color: #2c3e50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 0.95rem;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            text-align: left;
            vertical-align: middle;
        }

        th {
            background-color: #34495e;
            color: #ecf0f1;
            font-weight: 600;
        }

        tr:nth-child(even) {
            background-color: #f7f9fc;
        }

        a {
            color: #2980b9;
            text-decoration: none;
            font-weight: 600;
        }

        a:hover {
            text-decoration: underline;
        }

        select, textarea, button {
            font-family: inherit;
            font-size: 0.9rem;
        }

        select {
            padding: 6px 8px;
            border-radius: 6px;
            border: 1.5px solid #ccc;
            transition: border-color 0.3s ease;
            width: 130px;
        }

        select:focus {
            border-color: #2980b9;
            outline: none;
        }

        textarea {
            width: 100%;
            min-height: 70px;
            padding: 8px 10px;
            border-radius: 6px;
            border: 1.5px solid #ccc;
            resize: vertical;
            transition: border-color 0.3s ease;
        }

        textarea:focus {
            border-color: #2980b9;
            outline: none;
        }

        button {
            background-color: #2980b9;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 5px;
            margin-right: 6px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #1c5980;
        }

        span {
            font-weight: 600;
            color: green;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 20px 20px;
            }
            table, thead, tbody, th, td, tr {
                display: block;
            }
            thead tr {
                display: none;
            }
            tr {
                margin-bottom: 20px;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 15px;
                background-color: #fff;
            }
            td {
                padding: 8px 10px;
                border: none;
                position: relative;
                padding-left: 50%;
            }
            td:before {
                position: absolute;
                top: 8px;
                left: 15px;
                width: 45%;
                white-space: nowrap;
                font-weight: 600;
                color: #34495e;
            }
            td:nth-of-type(1):before { content: "Certificate Type"; }
            td:nth-of-type(2):before { content: "Purpose"; }
            td:nth-of-type(3):before { content: "Document"; }
            td:nth-of-type(4):before { content: "Status"; }
            td:nth-of-type(5):before { content: "Remarks"; }
            td:nth-of-type(6):before { content: "Action"; }
        }

        a.back-link {
            display: inline-block;
            margin-top: 25px;
            color: #2980b9;
            font-weight: 600;
            text-decoration: none;
        }

        a.back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Issue Certificates (Staff/Admin Panel)</h2>
    <table>
        <tr>
            <th>Certificate Type</th>
            <th>Purpose</th>
            <th>Document</th>
            <th>Status</th>
            <th>Remarks</th>
            <th>Action</th>
        </tr>

        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <form method="post" action="issue_certificate.php">
                    <td><?php echo htmlspecialchars($row['certificate_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['purpose']); ?></td>
                    <td>
                        <?php if (!empty($row['file_path'])): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View</a>
                        <?php else: ?>
                            No File
                        <?php endif; ?>
                    </td>
                    <td>
                        <select name="status">
                            <option value="Pending" <?php if ($row['status'] === 'Pending') echo 'selected'; ?>>Pending</option>
                            <option value="Verified" <?php if ($row['status'] === 'Verified') echo 'selected'; ?>>Verified</option>
                            <option value="Rejected" <?php if ($row['status'] === 'Rejected') echo 'selected'; ?>>Rejected</option>
                        </select>
                    </td>
                    <td><textarea name="remarks"><?php echo htmlspecialchars($row['remarks']); ?></textarea></td>
                    <td>
                        <input type="hidden" name="doc_id" value="<?php echo $row['doc_id']; ?>">
                        <input type="hidden" name="certificate_request_id" value="<?php echo $row['certificate_request_id']; ?>">
                        <button type="submit">Update</button>
                        <?php if ($row['status'] === 'Verified' && $row['issued'] == 0): ?>
                            <button type="submit" name="issue_certificate" value="1">Issue Certificate</button>
                        <?php elseif ($row['issued'] == 1): ?>
                            <span>Issued</span>
                        <?php endif; ?>
                    </td>
                </form>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6" style="text-align:center;">No certificate requests found.</td></tr>
        <?php endif; ?>
    </table>
    <a href="staff_dashboard.php" class="back-link">← Back to Dashboard</a>
</div>
</body>
</html>
