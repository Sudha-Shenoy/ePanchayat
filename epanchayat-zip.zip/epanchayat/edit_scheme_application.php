<?php
session_start();
require 'db.php';

if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$app_id = $_GET['id'] ?? 0;

// Fetch application with status either 'pending' or 'more_info'
$stmt = $conn->prepare("SELECT scheme_name, details FROM scheme_applications WHERE id = ? AND user_id = ? AND (status = 'pending' OR status = 'more_info')");
$stmt->bind_param("ii", $app_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Invalid application or status not editable.";
    exit();
}

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Scheme Application</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');

        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
            
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
            max-width: 600px;
            width: 100%;
        }

        h2 {
            margin-bottom: 25px;
            color: #0056b3;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }

        input[type="text"], textarea {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 20px;
            border: 1.8px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            resize: vertical;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, textarea:focus {
            border-color: #0056b3;
            outline: none;
        }

        input[readonly] {
            background-color: #f0f0f0;
            cursor: not-allowed;
        }

        textarea {
            min-height: 120px;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #0056b3;
            color: white;
            font-weight: 700;
            font-size: 18px;
            padding: 14px 0;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #003d80;
        }

        a {
            display: block;
            margin-top: 20px;
            text-align: center;
            font-weight: 600;
            color: #0056b3;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Edit Scheme Application</h2>
    <form method="post" action="update_scheme_application.php">
        <input type="hidden" name="id" value="<?php echo $app_id; ?>">

        <label for="scheme_name">Scheme Name (read-only):</label>
        <input type="text" id="scheme_name" name="scheme_name" value="<?php echo htmlspecialchars($row['scheme_name']); ?>" readonly>

        <label for="details">Details:</label>
        <textarea id="details" name="details" rows="5" required><?php echo htmlspecialchars($row['details']); ?></textarea>

        <input type="submit" value="Update Application">
    </form>
    <a href="apply_schemes.php">← Back to Schemes</a>
</div>
</body>
</html>
