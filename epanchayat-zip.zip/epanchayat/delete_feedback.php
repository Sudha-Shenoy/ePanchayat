<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'], $_POST['id'])) {
    $id = (int)$_POST['id'];

    $stmt = $conn->prepare("DELETE FROM complaints WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: manage_complaints.php");
    exit();
} else if (!isset($_POST['id']) && !isset($_GET['id'])) {
    die("No complaint ID provided.");
} else {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : (int)$_GET['id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Delete Complaint Confirmation</title>
<style>
  /* Style 7 Background: dark gradient with subtle noise pattern overlay */
  @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap');

  body {
    margin: 0;
    padding: 0;
    font-family: 'Montserrat', sans-serif;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background:
      linear-gradient(135deg, #2c3e50 0%, #000000 100%), /* dark gradient */
      url('https://www.transparenttextures.com/patterns/noise.png'); /* subtle noise pattern */
    background-repeat: repeat;
    color: #f0f0f0;
  }

  .confirm-box {
    background: rgba(40, 44, 52, 0.9);
    padding: 40px 50px;
    border-radius: 12px;
    box-shadow:
      0 8px 24px rgba(0, 0, 0, 0.8),
      inset 0 0 10px rgba(255, 255, 255, 0.05);
    max-width: 420px;
    text-align: center;
    border: 2px solid #3f51b5;
  }

  h2 {
    font-weight: 700;
    margin-bottom: 30px;
    font-size: 1.8rem;
    letter-spacing: 0.05em;
    color: #82aaff;
    text-shadow: 0 0 8px #5c6bc0;
  }

  button {
    background-color: #e53935;
    border: none;
    padding: 14px 32px;
    font-size: 1.1rem;
    color: white;
    font-weight: 600;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    box-shadow: 0 4px 10px rgba(229, 57, 53, 0.6);
    margin-right: 15px;
  }

  button:hover {
    background-color: #b71c1c;
    box-shadow: 0 6px 18px rgba(183, 28, 28, 0.8);
  }

  a.cancel-link {
    font-size: 1.1rem;
    font-weight: 600;
    color: #82aaff;
    text-decoration: none;
    vertical-align: middle;
    padding: 14px 24px;
    border-radius: 8px;
    border: 2px solid #82aaff;
    transition: background-color 0.3s ease, color 0.3s ease;
  }

  a.cancel-link:hover {
    background-color: #82aaff;
    color: #1a237e;
  }
</style>
</head>
<body>
<div class="confirm-box">
    <h2>Are you sure you want to delete this complaint?</h2>
    <form method="POST" action="">
        <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">
        <button type="submit" name="delete">Yes, Delete</button>
        <a href="manage_complaints.php" class="cancel-link">Cancel</a>
    </form>
</div>
</body>
</html>
