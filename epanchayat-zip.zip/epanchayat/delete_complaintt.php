<?php
session_start();
require 'db.php';

if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

$complaint_id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("DELETE FROM complaints WHERE id = ? AND user_id = ? AND status = 'pending'");
$stmt->bind_param("ii", $complaint_id, $user_id);

if ($stmt->execute()) {
    header("Location: complaints.php");
    exit();
} else {
    echo "Error deleting complaint.";
}
?>
