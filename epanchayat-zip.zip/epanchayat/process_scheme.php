<?php
include 'db.php';
$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM scheme_applications WHERE id = $id");
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Process Scheme Application</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

    body {
      margin: 0;
      padding: 0;
      font-family: 'Roboto', sans-serif;
      background:
        linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),
        
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    .container {
      background: #fff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
      width: 500px;
      max-width: 90%;
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 20px;
    }

    p {
      font-size: 1.1rem;
      color: #333;
      margin: 10px 0;
    }

    label {
      font-weight: bold;
      display: block;
      margin: 15px 0 8px;
    }

    textarea {
      width: 100%;
      padding: 10px;
      font-size: 1rem;
      border-radius: 6px;
      border: 1px solid #ccc;
      resize: vertical;
    }

    button {
      background-color: #3498db;
      color: #fff;
      border: none;
      padding: 10px 15px;
      font-size: 1rem;
      margin-right: 10px;
      border-radius: 6px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #2c80b4;
    }

    a {
      display: inline-block;
      margin-top: 20px;
      text-decoration: none;
      color: #2980b9;
    }

    a:hover {
      color: #1c5980;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Process Application ID: <?= htmlspecialchars($row['id']) ?></h2>
  <p><strong>Scheme:</strong> <?= htmlspecialchars($row['scheme_name']) ?></p>
  <p><strong>Details:</strong> <?= nl2br(htmlspecialchars($row['details'])) ?></p>
  <p><strong>Status:</strong> <?= ucfirst(htmlspecialchars($row['status'])) ?></p>

  <form method="post" action="process_scheme_action.php">
    <input type="hidden" name="id" value="<?= $row['id'] ?>">
    
    <label for="remarks">Remarks:</label>
    <textarea name="remarks" id="remarks" rows="4" required></textarea>

    <br><br>
    <button type="submit" name="action" value="approve">Approve</button>
    <button type="submit" name="action" value="reject" style="background-color:#e74c3c;">Reject</button>
    <button type="submit" name="action" value="more_info" style="background-color:#f39c12;">Request Info</button>
  </form>

  <a href="view_scheme_applications.php">← Back</a>
</div>

</body>
</html>
