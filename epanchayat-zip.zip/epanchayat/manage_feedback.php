<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php");
    exit();
}
include 'db.php';

$query = "SELECT f.id, f.title, f.message, f.submit_date, f.status, u.username AS user_name 
          FROM feedback f
          JOIN users u ON f.user_id = u.id 
          ORDER BY f.submit_date DESC";

$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Manage Feedback</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');

        body {
            font-family: 'Open Sans', Arial, sans-serif;
            margin: 0; padding: 0;
            background:
                linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
                
            background-size: cover;
            color: #f0f0f0;
        }
        .container {
            max-width: 1100px;
            margin: 40px auto;
            background: rgba(255, 255, 255, 0.95);
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            color: #333;
        }
        h1 {
            text-align: center;
            margin-bottom: 25px;
            color: #2c3e50;
            font-weight: 700;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            vertical-align: top;
        }
        th {
            background-color: #34495e;
            color: #ecf0f1;
            font-weight: 600;
            text-align: left;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        a {
            color: #2980b9;
            text-decoration: none;
            font-weight: 600;
            margin-right: 10px;
        }
        a:hover {
            text-decoration: underline;
        }
        em {
            color: #777;
            font-style: italic;
        }
        .back-link {
            display: inline-block;
            margin-top: 30px;
            font-weight: 600;
            color: #2980b9;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                margin: 20px 10px;
                padding: 20px;
            }
            table, thead, tbody, th, td, tr {
                display: block;
            }
            thead tr {
                display: none;
            }
            tr {
                margin-bottom: 20px;
                background: #fff;
                border-radius: 8px;
                padding: 15px;
                box-shadow: 0 0 8px rgba(0,0,0,0.1);
            }
            td {
                border: none;
                padding-left: 50%;
                position: relative;
                text-align: left;
            }
            td:before {
                position: absolute;
                top: 12px;
                left: 15px;
                width: 45%;
                white-space: nowrap;
                font-weight: 700;
                color: #34495e;
            }
            td:nth-of-type(1):before { content: "User"; }
            td:nth-of-type(2):before { content: "Title"; }
            td:nth-of-type(3):before { content: "Message"; }
            td:nth-of-type(4):before { content: "Submit Date"; }
            td:nth-of-type(5):before { content: "Status"; }
            td:nth-of-type(6):before { content: "Actions"; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>User Feedbacks</h1>
        <table>
            <thead>
                <tr>
                    <th>User</th>
                    <th>Title</th>
                    <th>Message</th>
                    <th>Submit Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($feedback = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($feedback['user_name']) ?></td>
                    <td><?= htmlspecialchars($feedback['title']) ?></td>
                    <td><?= htmlspecialchars($feedback['message']) ?></td>
                    <td><?= $feedback['submit_date'] ?></td>
                    <td><?= ucfirst($feedback['status']) ?></td>
                    <td>
                        <?php if (strtolower($feedback['status']) === 'pending'): ?>
                            <a href="resolve_feedback.php?id=<?= $feedback['id'] ?>">Resolve</a>
                            <a href="close_feedback.php?id=<?= $feedback['id'] ?>">Close</a>
                        <?php else: ?>
                            <em>No actions</em>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="<?= ($_SESSION['role'] === 'admin') ? 'admin_dashboard.php' : 'staff_dashboard.php'; ?>" class="back-link">← Back to Dashboard</a>
    </div>
</body>
</html>
