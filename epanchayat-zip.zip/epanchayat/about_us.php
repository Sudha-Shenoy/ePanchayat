<!-- about_us.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us - ePanchayat</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('assets/default-bg.jpeg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #ffffff;
            min-height: 100vh;
        }
        .section {
            max-width: 800px;
            margin: 80px auto;
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.4);
        }
        h2 {
            font-size: 2em;
            margin-bottom: 20px;
            color: #00bfff;
            border-bottom: 2px solid #00bfff;
            display: inline-block;
            padding-bottom: 5px;
        }
        p {
            font-size: 1.1em;
            line-height: 1.6;
            color: #f1f1f1;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="section" id="about">
        <h2>About Us</h2>
        <p>
            Welcome to the ePanchayat system — a digital initiative aimed at bringing transparency, convenience,
            and efficiency to village administration. Our platform empowers citizens by allowing them to access
            essential services such as applying for schemes, submitting complaints, requesting certificates,
            viewing notices, and paying taxes online.
        </p>
        <p>
            The goal is to bridge the gap between the panchayat office and residents, ensuring that governance is
            accessible and responsive to everyone in the community.
        </p>
        <a href="index.php">Back</a>
    </div>
</body>
</html>

