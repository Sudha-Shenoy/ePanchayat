<?php
// process_scheme_decision.php
session_start();
include 'db.php';

$id = $_POST['id'];
$status = $_POST['status'];
$message = $_POST['message'];
$staff_id = $_SESSION['staff_id'];

$sql = "UPDATE scheme_applications 
        SET status = ?, message = ?, reviewed_by = ?, review_date = NOW() 
        WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssii", $status, $message, $staff_id, $id);
$success = $stmt->execute();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Decision Processed</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background:
        linear-gradient(rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.9)),
        
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .notification-card {
      background: #fff;
      padding: 40px 50px;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      text-align: center;
      max-width: 500px;
    }

    h2 {
      color: <?= $success ? '#27ae60' : '#c0392b' ?>;
      margin-bottom: 15px;
    }

    p {
      font-size: 1.1rem;
      color: #555;
      margin-bottom: 30px;
    }

    a {
      text-decoration: none;
      padding: 12px 20px;
      background-color: #2980b9;
      color: #fff;
      border-radius: 6px;
      font-size: 1rem;
      transition: background-color 0.3s ease;
    }

    a:hover {
      background-color: #1f5d85;
    }
  </style>
</head>
<body>

<div class="notification-card">
  <?php if ($success): ?>
    <h2>Application Updated</h2>
    <p>Status changed to: <strong><?= ucfirst(htmlspecialchars($status)) ?></strong></p>
  <?php else: ?>
    <h2>Update Failed</h2>
    <p>There was an issue processing the application decision.</p>
  <?php endif; ?>
  <a href="view_scheme_applications.php">← Back to Applications</a>
</div>

</body>
</html>
