<?php
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Close Feedback</title>
    <style>
        body {
           
            background-size: cover;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #fff;
        }

        .container {
            max-width: 500px;
            margin: 120px auto;
            background: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.5);
        }

        h2 {
            margin-bottom: 20px;
        }

        p {
            font-size: 18px;
        }

        a {
            color: #00d4ff;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("UPDATE feedback SET status = 'closed' WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<h2>Feedback Closed</h2>";
        echo "<p>The feedback has been successfully marked as closed.</p>";
        echo "<meta http-equiv='refresh' content='2;url=manage_feedback.php'>";
    } else {
        echo "<h2>Error</h2>";
        echo "<p>There was a problem closing the feedback: " . htmlspecialchars($stmt->error) . "</p>";
        echo "<a href='manage_feedback.php'>Back to Feedback</a>";
    }
} else {
    echo "<h2>Invalid Request</h2>";
    echo "<p>No feedback ID provided.</p>";
    echo "<a href='manage_feedback.php'>Back to Feedback</a>";
}
?>
</div>

</body>
</html>
