<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Validate feedback ID
if (!isset($_GET['feedback_id']) || empty($_GET['feedback_id'])) {
    echo "Invalid feedback ID.";
    exit();
}

$feedback_id = intval($_GET['feedback_id']);

// Fetch the feedback to be edited
$stmt = $conn->prepare("SELECT * FROM feedback WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $feedback_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "Feedback not found or access denied.";
    exit();
}

$feedback = $result->fetch_assoc();

// Handle update
if (isset($_POST['update_feedback'])) {
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);

    $update = $conn->prepare("UPDATE feedback SET title = ?, message = ? WHERE id = ? AND user_id = ?");
    $update->bind_param("ssii", $title, $message, $feedback_id, $user_id);
    $update->execute();

    echo "<script>alert('Feedback updated successfully!'); window.location.href='give_feedback.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit Feedback</title>
<style>
  body {
    margin: 0; padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #333;
  }
  .container {
    background: rgba(255, 255, 255, 0.95);
    padding: 30px 40px;
    border-radius: 10px;
    width: 400px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.25);
  }
  h2 {
    margin-bottom: 25px;
    text-align: center;
    color: #007acc;
  }
  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
  }
  input[type="text"], textarea {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    box-sizing: border-box;
    resize: vertical;
  }
  input[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #007acc;
    border: none;
    border-radius: 6px;
    color: white;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  input[type="submit"]:hover {
    background-color: #005fa3;
  }
</style>
</head>
<body>
  <div class="container">
    <h2>Edit Feedback</h2>
    <form method="POST">
      <label for="title">Title:</label>
      <input type="text" id="title" name="title" value="<?= htmlspecialchars($feedback['title']) ?>" required>

      <label for="message">Message:</label>
      <textarea id="message" name="message" rows="5" required><?= htmlspecialchars($feedback['message']) ?></textarea>

      <input type="submit" name="update_feedback" value="Update Feedback">
    </form>
  </div>

</body>
</html>
