<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php");
    exit();
}

include 'db.php'; 

$sql = "SELECT complaints.id, users.username AS name, subject, message, status, created_at 
        FROM complaints 
        JOIN users ON complaints.user_id = users.id 
        ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<html>
<head>
    <title>Manage Complaints</title>
    <style>
        body { font-family: Arial; background-color: #f9f9f9; padding: 20px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: left; }
        th { background-color: #007bff; color: white; }
        .btn { padding: 6px 10px; border: none; cursor: pointer; margin: 2px; }
        .resolve { background-color: green; color: white; }
        .delete { background-color: red; color: white; }
        form { display: inline; }
    </style>
</head>
<body>
    <h2>Manage Complaints</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>User</th>
            <th>Subject</th>
            <th>Message</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
        </tr>

        <?php while($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= htmlspecialchars($row['name']); ?></td>
            <td><?= htmlspecialchars($row['subject']); ?></td>
            <td><?= htmlspecialchars($row['message']); ?></td>
            <td><?= $row['status']; ?></td>
            <td><?= $row['created_at']; ?></td>
            <td>
                <?php if($row['status'] === 'Pending') { ?>
                    <form method="post" action="update_complaint_status.php">
                        <input type="hidden" name="id" value="<?= $row['id']; ?>">
                        <button type="submit" name="resolve" class="btn resolve">Mark Resolved</button>
                    </form>
                <?php } ?>
                <form method="post" action="delete_complaint.php" onsubmit="return confirm('Are you sure?');">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <button type="submit" name="delete" class="btn delete">Delete</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>

    <!-- Dynamic back link -->
    <a href="<?= ($_SESSION['role'] === 'admin') ? 'admin_dashboard.php' : 'staff_dashboard.php'; ?>">Back to Dashboard</a>
</body>
</html>
