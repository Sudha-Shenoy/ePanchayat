<?php
include 'db.php';

if (!isset($_GET['receipt_no'])) {
    echo "No receipt number provided.";
    exit;
}

$receipt_no = $_GET['receipt_no'];

$sql = "SELECT tp.*, tt.name AS tax_name, u.username AS user_name
        FROM tax_payments tp
        JOIN tax_types tt ON tp.tax_type_id = tt.id
        JOIN users u ON tp.user_id = u.id
        WHERE tp.receipt_no = ?";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Error preparing the SQL query: ' . $conn->error);
}

$stmt->bind_param("s", $receipt_no);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Receipt not found.";
    exit;
}

$receipt = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Tax Payment Receipt</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap');

  body {
    font-family: 'Roboto Slab', serif;
    background:
      
    background-size: cover;
    margin: 0;
    padding: 30px;
    color: #222;
  }

  .receipt-container {
    max-width: 600px;
    background: rgba(255, 255, 255, 0.95);
    margin: auto;
    padding: 30px 40px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
  }

  h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #2c3e50;
  }

  p {
    font-size: 1.1rem;
    margin: 8px 0;
  }

  hr {
    margin: 25px 0;
    border: none;
    border-top: 1.5px solid #ccc;
  }

  a {
    display: block;
    text-align: center;
    margin-top: 25px;
    font-weight: 600;
    color: #2980b9;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }

  @media print {
    body {
      background: none;
      padding: 0;
    }
    .receipt-container {
      box-shadow: none;
      border-radius: 0;
      margin: 0;
      padding: 0;
    }
    a {
      display: none;
    }
  }
</style>
</head>
<body onload="window.print()">
  <div class="receipt-container">
    <h2>ePanchayat Tax Payment Receipt</h2>
    <p><strong>Receipt No:</strong> <?= htmlspecialchars($receipt['receipt_no']) ?></p>
    <p><strong>Tax Type:</strong> <?= htmlspecialchars($receipt['tax_name']) ?></p>
    <p><strong>Paid By:</strong> <?= htmlspecialchars($receipt['user_name']) ?></p>
    <p><strong>Amount Paid:</strong> ₹<?= number_format($receipt['amount_paid'], 2) ?></p>
    <p><strong>Payment Date:</strong> <?= htmlspecialchars($receipt['payment_date']) ?></p>
    <p><strong>Payment Method:</strong> <?= htmlspecialchars($receipt['method']) ?></p>
    <hr>
    <p style="text-align:center;">Thank you for your payment!</p>
    <a href="view_tax_details.php">← Back to Tax Dashboard</a>
  </div>
</body>
</html>
