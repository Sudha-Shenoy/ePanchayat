<?php
session_start();
if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

require 'db.php';

$user_id = $_SESSION['user_id'];

// Fetch available schemes
$scheme_stmt = $conn->prepare("SELECT id, name, description, eligibility, last_date FROM schemes WHERE status = 'active'");
$scheme_stmt->execute();
$schemes = $scheme_stmt->get_result();

// Fetch user's past applications
$app_stmt = $conn->prepare("SELECT id, scheme_name, details, status, submitted_at FROM scheme_applications WHERE user_id = ?");
$app_stmt->bind_param("i", $user_id);
$app_stmt->execute();
$applications = $app_stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Apply for Schemes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            
            background-size: cover;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.3);
        }

        h2 {
            color: #2d572c;
            text-align: center;
        }

        label {
            font-weight: bold;
        }

        select, textarea, input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
        }

        th, td {
            border: 1px solid #aaa;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            color: #007BFF;
        }

        a:hover {
            text-decoration: underline;
        }

        hr {
            margin: 40px 0 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Apply for Available Schemes</h2>
    <form action="submit_scheme_application.php" method="post">
        <label for="scheme_name">Select Scheme:</label>
        <select name="scheme_name" required>
            <option value="">--Choose a scheme--</option>
            <?php while ($row = $schemes->fetch_assoc()) { ?>
                <option value="<?php echo htmlspecialchars($row['name']); ?>">
                    <?php echo htmlspecialchars($row['name']) . " - " . htmlspecialchars($row['description']) . " (Last Date: " . $row['last_date'] . ")"; ?>
                </option>
            <?php } ?>
        </select>

        <label for="details">Why are you applying (Details):</label>
        <textarea name="details" rows="4" required></textarea>

        <input type="submit" value="Apply">
    </form>

    <hr>
    <h2>Your Past Applications</h2>
    <?php if ($applications->num_rows > 0): ?>
        <table>
            <tr>
                <th>Scheme Name</th>
                <th>Details</th>
                <th>Status</th>
                <th>Submitted At</th>
                <th>Actions</th>
            </tr>
            <?php while ($app = $applications->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($app['scheme_name']); ?></td>
                    <td><?php echo htmlspecialchars($app['details']); ?></td>
                    <td><?php echo htmlspecialchars($app['status']); ?></td>
                    <td><?php echo $app['submitted_at']; ?></td>
                    <td>
                        <?php if ($app['status'] === 'pending' || $app['status'] === 'more_info'): ?>
                            <a href="edit_scheme_application.php?id=<?php echo $app['id']; ?>">Edit</a> |
                            <a href="delete_scheme_application.php?id=<?php echo $app['id']; ?>" onclick="return confirm('Are you sure you want to delete this application?');">Delete</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No applications found.</p>
    <?php endif; ?>

    <br><a href="apply_schemes.php">Back to Dashboard</a>
</div>
</body>
</html>
