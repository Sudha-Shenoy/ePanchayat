<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us - ePanchayat</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('assets/contact.jpeg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #ffffff;
            min-height: 100vh;
        }
        .section {
            max-width: 600px;
            margin: 60px auto;
            background-color: rgba(0, 0, 0, 0.65);
            padding: 30px 25px;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.3);
        }
        h2 {
            font-size: 1.8em;
            margin-bottom: 18px;
            color: #00bfff;
            border-bottom: 2px solid #00bfff;
            display: inline-block;
            padding-bottom: 4px;
        }
        p, li {
            font-size: 1em;
            line-height: 1.5;
            color: #e0e0e0;
        }
        ul {
            list-style: none;
            padding-left: 0;
            margin-bottom: 20px;
        }
        li {
            margin-bottom: 8px;
        }
        form label {
            font-weight: 500;
        }
        input[type="text"],
        textarea {
            width: 100%;
            padding: 8px;
            margin-top: 4px;
            margin-bottom: 16px;
            border-radius: 5px;
            border: none;
            font-size: 0.95em;
        }
        textarea {
            resize: vertical;
        }
        button {
            background-color: #007acc;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            font-size: 0.85em;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        button:hover {
            background-color: #005f99;
        }
    </style>
</head>
<body>
    <div class="section" id="contact">
        <h2>Contact Us</h2>
        <p>If you have any questions, concerns, or feedback, feel free to reach out to us:</p>
        <ul>
            <li><strong>Address:</strong> Panchayat Bhawan, Main Road, abc</li>
            <li><strong>Email:</strong> support@epanchayat.in</li>
            <li><strong>Phone:</strong> +91-9988553321</li>
        </ul>

        <form action="submit_contact.php" method="POST">
            <label for="name">Your Name:</label><br>
            <input type="text" id="name" name="name" required><br>

            <label for="message">Your Message:</label><br>
            <textarea id="message" name="message" rows="4" required></textarea><br>

            <button type="submit">Send Message</button>
        </form>
        <button type="submit"><a href="index.php">Back</a></button>
    </div>
</body>
</html>
