<?php
session_start();
if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

require 'db.php';

$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $subject = trim($_POST['subject']);
    $message_text = trim($_POST['message']);

    $stmt = $conn->prepare("INSERT INTO complaints (user_id, subject, message, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");

    if (!$stmt) {
        $message = "Prepare failed: " . $conn->error;
    } else {
        $stmt->bind_param("iss", $user_id, $subject, $message_text);
        if ($stmt->execute()) {
            $message = "✅ Complaint submitted successfully!";
            $success = true;
        } else {
            $message = "❌ Error submitting complaint: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Complaint Submission</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(rgba(255,255,255,0.85), rgba(255,255,255,0.85)),
                       
            background-size: cover;
        }

        .container {
            max-width: 600px;
            margin: 80px auto;
            background: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.15);
            text-align: center;
        }

        p {
            font-size: 1.2em;
            color: <?= $success ? '#27ae60' : '#c0392b' ?>;
            margin-bottom: 20px;
        }

        a {
            text-decoration: none;
            margin: 0 10px;
            color: #2980b9;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <p><?= htmlspecialchars($message) ?></p>
    <a href="submit_complaint.php">Submit Another</a> | 
    <a href="complaints.php">Back</a>
</div>
</body>
</html>
