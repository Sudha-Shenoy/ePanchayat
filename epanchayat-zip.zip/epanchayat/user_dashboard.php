<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <style>
        body {
            background: url('assets/user-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 20px;
        }
        .content-wrapper {
            background: rgba(0, 0, 0, 0.6);
            padding: 20px;
            border-radius: 10px;
            max-width: 800px;
            margin: 40px auto;
        }
    </style>
</head>
<body>
    <div class="content-wrapper">
      <?php
session_start();
if ($_SESSION['role'] !== 'user') {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>User Dashboard</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="user-dashboard">
  <div class="container">
    <h1>Welcome User: <?php echo $_SESSION['username']; ?></h1>
    <ul>
      <li><a href="apply_schemes.php">Apply for Schemes</a></li>
      <li><a href="complaints.php">View & Submit Complaints</a></li>
      <li><a href="request_certificates.php">Request Certificates</a></li>
      <li><a href="view_notices.php">View Notices/Events</a></li>
      <li><a href="give_feedback.php">Give Feedback</a></li>
      <li><a href="view_tax_details.php">Pay Taxes</a></li>
    </ul>
    <a href="logout.php" style="color: red;">Logout</a>
  </div>
</body>
</html>
    </div>
</body>
</html>
