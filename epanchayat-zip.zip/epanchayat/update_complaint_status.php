<?php
include 'db.php';

if (isset($_POST['resolve'])) {
    $id = $_POST['id'];

    $stmt = $conn->prepare("UPDATE complaints SET status='Resolved' WHERE id=?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: manage_complaints.php");
        exit();
    } else {
        // Execution error fallback
        $error = $stmt->error;
    }
} else {
    $error = "Invalid access. No complaint specified.";
}
?>

<!-- Error fallback UI -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Error Resolving Complaint</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .error-box {
            max-width: 500px;
            margin: 100px auto;
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            text-align: center;
        }
        .error-box h2 {
            color: #e74c3c;
        }
        .error-box p {
            color: #333;
        }
        .error-box a {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 15px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .error-box a:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="error-box">
        <h2>Error</h2>
        <p><?= htmlspecialchars($error) ?></p>
        <a href="manage_complaints.php">Back to Complaint Management</a>
    </div>
</body>
</html>
