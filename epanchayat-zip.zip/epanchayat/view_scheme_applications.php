<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    die("Access denied. Please login.");
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Fetch all scheme applications
$query = "SELECT sa.*, u.username AS applicant_name, s.username AS staff_name
          FROM scheme_applications sa
          LEFT JOIN users u ON sa.user_id = u.id
          LEFT JOIN users s ON sa.assigned_to = s.id";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Scheme Applications</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            
            background-size: cover;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 95%;
            margin: 40px auto;
            background-color: rgba(255, 255, 255, 0.96);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #bbb;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #34495e;
            color: #fff;
        }

        td {
            background-color: #f9f9f9;
        }

        tr:nth-child(even) td {
            background-color: #e9e9e9;
        }

        form {
            display: inline-block;
            margin: 0;
        }

        select, button {
            padding: 5px;
            margin-top: 5px;
            font-size: 14px;
        }

        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            font-weight: bold;
            color: #2980b9;
        }

        a:hover {
            color: #d35400;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Scheme Applications</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>Scheme</th>
                <th>Applicant</th>
                <th>Status</th>
                <th>Assigned To</th>
                <th>Submitted At</th>
                <th>Actions</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($result)) {
                if ($role == 'staff' && $row['assigned_to'] != $user_id) {
                    continue;
                }
            ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= htmlspecialchars($row['scheme_name']); ?></td>
                <td><?= htmlspecialchars($row['applicant_name']); ?></td>
                <td><?= htmlspecialchars($row['status']); ?></td>
                <td><?= $row['staff_name'] ? $row['staff_name'] : 'Unassigned'; ?></td>
                <td><?= $row['submitted_at']; ?></td>
                <td>
                    <?php if ($role == 'admin') { ?>
                        <form method="POST" action="assign_staff.php">
                            <input type="hidden" name="application_id" value="<?= $row['id']; ?>">
                            <select name="staff_id" required>
                                <option value="">Assign</option>
                                <?php
                                $staffs = mysqli_query($conn, "SELECT id, username FROM users WHERE role='staff'");
                                while ($staff = mysqli_fetch_assoc($staffs)) {
                                    $selected = ($row['assigned_to'] == $staff['id']) ? 'selected' : '';
                                    echo "<option value='{$staff['id']}' $selected>{$staff['username']}</option>";
                                }
                                ?>
                            </select>
                            <button type="submit">Assign</button>
                        </form>
                    <?php } ?>

                    <form method="GET" action="process_scheme.php">
                        <input type="hidden" name="id" value="<?= $row['id']; ?>">
                        <button type="submit">Process</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </table>

        <a href="<?= ($_SESSION['role'] === 'admin') ? 'admin_dashboard.php' : 'staff_dashboard.php'; ?>">← Back to Dashboard</a>
    </div>
</body>
</html>
