<?php
session_start();
require 'db.php';

if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE complaints SET subject = ?, message = ? WHERE id = ? AND user_id = ? AND status = 'pending'");
    $stmt->bind_param("ssii", $subject, $message, $id, $user_id);

    if ($stmt->execute()) {
        header("Location: complaints.php");
        exit();
    } else {
        // Show styled error
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Error Updating Complaint</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    
                    background-size: cover;
                    margin: 0;
                    padding: 0;
                }
                .error-box {
                    max-width: 500px;
                    margin: 100px auto;
                    background: rgba(255, 255, 255, 0.95);
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
                    text-align: center;
                }
                .error-box h2 {
                    color: #c0392b;
                }
                .error-box p {
                    color: #333;
                    font-size: 1.1rem;
                }
                .error-box a {
                    display: inline-block;
                    margin-top: 15px;
                    padding: 10px 15px;
                    background-color: #2980b9;
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                }
                .error-box a:hover {
                    background-color: #1f6390;
                }
            </style>
        </head>
        <body>
            <div class="error-box">
                <h2>Update Failed</h2>
                <p>Error updating complaint: <?= htmlspecialchars($stmt->error) ?></p>
                <a href="complaints.php">Back to Complaints</a>
            </div>
        </body>
        </html>
        <?php
    }
}
?>
