<?php
include 'db.php';

$id = $_POST['id'];
$action = $_POST['action'];
$remarks = mysqli_real_escape_string($conn, $_POST['remarks']);

$status_map = [
    'approve' => 'approved',
    'reject' => 'rejected',
    'more_info' => 'more_info'
];

$status = $status_map[$action];

$sql = "UPDATE scheme_applications 
        SET status = '$status', remarks = '$remarks' 
        WHERE id = $id";

$success = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Application Status</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

    body {
      margin: 0;
      font-family: 'Roboto', sans-serif;
      background:
        linear-gradient(rgba(255,255,255,0.95), rgba(255,255,255,0.95)),
        
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .message-box {
      background: #fff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.15);
      text-align: center;
      max-width: 500px;
    }

    h2 {
      color: <?= $success ? '#27ae60' : '#c0392b' ?>;
      margin-bottom: 20px;
    }

    p {
      font-size: 1.1rem;
      margin-bottom: 20px;
    }

    a {
      display: inline-block;
      padding: 10px 20px;
      text-decoration: none;
      color: white;
      background-color: #2980b9;
      border-radius: 6px;
      transition: background-color 0.3s ease;
    }

    a:hover {
      background-color: #1c5980;
    }
  </style>
</head>
<body>

<div class="message-box">
  <?php if ($success): ?>
    <h2>Application Updated</h2>
    <p>Status changed to: <strong><?= ucfirst($status) ?></strong></p>
  <?php else: ?>
    <h2>Error</h2>
    <p>There was an error updating the application.</p>
  <?php endif; ?>
  <a href="view_scheme_applications.php">← Back to Applications</a>
</div>

</body>
</html>
