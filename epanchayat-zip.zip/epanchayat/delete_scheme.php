<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

include("db.php");

$message = '';
if (isset($_GET['id'])) {
    $scheme_id = (int)$_GET['id'];

    // Secure delete using prepared statement
    $stmt = $conn->prepare("DELETE FROM schemes WHERE id = ?");
    $stmt->bind_param("i", $scheme_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: manage_services.php?msg=Scheme+deleted+successfully");
        exit();
    } else {
        $message = "Error: Scheme not found or already deleted.";
    }

    $stmt->close();
} else {
    $message = "Invalid scheme ID.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Delete Scheme</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background: #2c3e50;
    color: #f0f0f0;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .container {
    background: rgba(44, 62, 80, 0.9);
    padding: 30px 40px;
    border-radius: 10px;
    box-shadow: 0 0 15px #000;
    text-align: center;
    max-width: 400px;
  }
  a {
    color: #82aaff;
    text-decoration: none;
    font-weight: bold;
    margin-top: 20px;
    display: inline-block;
  }
  a:hover {
    text-decoration: underline;
  }
  h2 {
    margin-bottom: 20px;
  }
</style>
</head>
<body>
<div class="container">
    <h2><?= htmlspecialchars($message) ?></h2>
    <a href="manage_services.php">Back </a>
</div>
</body>
</html>
