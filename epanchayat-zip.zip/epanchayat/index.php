<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ePanchayat - Home</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('assets/index.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #ffffff;
            min-height: 100vh;
            display: flex;
            align-items: flex-start;   /* Push content up */
            justify-content: flex-start; /* Align to left */
        }
        .content-wrapper {
            padding: 40px 30px;
            max-width: 600px;
            width: 100%;
            margin-top: 30px;     /* Push content down slightly */
            margin: left 20px;
        }
        h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        p {
            font-size: 1.2em;
            margin-bottom: 25px;
            color: #ffffff;
        }
        .nav-links {
            text-align: left;
            padding-left: 10px;
        }
        .nav-links a {
            display: block;
            margin: 8px 0;
            padding: 10px 18px;
            border-radius: 6px;
            background-color: rgba(0, 122, 204, 0.9);
            color: white;
            text-decoration: none;
            transition: background 0.3s ease;
            font-weight: 500;
            width: fit-content;
        }
        .nav-links a:hover {
            background-color: rgba(0, 95, 153, 0.95);
        }
    </style>
</head>
<body>
    <div class="content-wrapper">
        <h1>Welcome to <strong>ePanchayat</strong></h1>
        <p>Your digital platform for village governance</p>
        <div class="nav-links">
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
            <a href="about_us.php">About Us</a>
            <a href="contact_us.php">Contact Us</a>
        </div>
    </div>
</body>
</html>
