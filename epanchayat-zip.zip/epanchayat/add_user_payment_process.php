<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $tax_type_id = $_POST['tax_type_id'];
    $amount_paid = $_POST['amount_paid'];
    $method = $_POST['method'];
    $payment_date = date('Y-m-d');
    $receipt_no = 'RCPT' . time();

    $sql = "INSERT INTO tax_payments (user_id, tax_type_id, amount_paid, method, payment_date, receipt_no)
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("iidsss", $user_id, $tax_type_id, $amount_paid, $method, $payment_date, $receipt_no);
        $stmt->execute();
        $stmt->close();

        $user = $conn->query("SELECT username FROM users WHERE id = $user_id")->fetch_assoc();
        $tax = $conn->query("SELECT name FROM tax_types WHERE id = $tax_type_id")->fetch_assoc();
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Payment Success</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    
                    background-size: cover;
                    margin: 0;
                }
                .container {
                    background: rgba(255, 255, 255, 0.95);
                    padding: 30px;
                    width: 600px;
                    margin: 60px auto;
                    border-radius: 10px;
                    box-shadow: 0 0 10px #555;
                }
                h2 {
                    color: green;
                    text-align: center;
                    font-size: 24px;
                }
                .details {
                    margin-top: 20px;
                    font-size: 16px;
                }
                .details p {
                    margin: 10px 0;
                }
                .btn {
                    display: inline-block;
                    margin-top: 20px;
                    padding: 10px 20px;
                    background: #007BFF;
                    color: #fff;
                    text-decoration: none;
                    border-radius: 6px;
                    margin-right: 10px;
                }
                .btn:hover {
                    background-color: #0056b3;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>✅ Payment Added Successfully</h2>
                <div class="details">
                    <p><strong>User:</strong> <?= htmlspecialchars($user['username']) ?></p>
                    <p><strong>Tax Type:</strong> <?= htmlspecialchars($tax['name']) ?></p>
                    <p><strong>Amount:</strong> ₹<?= number_format($amount_paid, 2) ?></p>
                    <p><strong>Method:</strong> <?= ucfirst($method) ?></p>
                    <p><strong>Date:</strong> <?= $payment_date ?></p>
                    <p><strong>Receipt No:</strong> <?= $receipt_no ?></p>
                </div>
                <a class="btn" href="add_user_payment.php">Add Another Payment</a>
                <a class="btn" href="view_user_payments.php">Back</a>
            </div>
        </body>
        </html>
        <?php
    } else {
        die("Query failed: " . $conn->error);
    }
} else {
    echo "<h3 style='color:red;'>Invalid request.</h3>";
}
