<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php");
    exit();
}
include 'db.php';

// Fetch uploaded assets
$sql = "SELECT * FROM assets ORDER BY uploaded_at DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Error fetching data: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Uploaded Assets</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            
            background-size: cover;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1000px;
            margin: 50px auto;
            background-color: rgba(255, 255, 255, 0.96);
            padding: 25px 30px;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.4);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 30px;
        }

        a {
            color: #2980b9;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #999;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #2c3e50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f4f4f4;
        }

        td a {
            margin-right: 10px;
            color: #2c3e50;
        }

        td a:hover {
            color: #d35400;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Uploaded Village Assets & Census Data</h2>

    <a href="upload_assets.php">← Upload New Asset</a><br><br>

    <table>
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>File</th>
            <th>Uploaded At</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= htmlspecialchars($row['title']); ?></td>
                <td><?= htmlspecialchars($row['description']); ?></td>
                <td><a href="<?= $row['file_path']; ?>" target="_blank">View File</a></td>
                <td><?= $row['uploaded_at']; ?></td>
                <td>
                    <a href="edit_asset.php?id=<?= $row['id']; ?>">Edit</a>
                    <a href="delete_asset.php?id=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this asset?');">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <br><a href="<?= ($_SESSION['role'] === 'admin') ? 'admin_dashboard.php' : 'staff_dashboard.php'; ?>">← Back to Dashboard</a>
</div>
</body>
</html>
