<?php
session_start();
include 'db.php';

$user_id = $_SESSION['user_id'];

// Fetch tax records
$sql = "SELECT utd.id AS tax_id, tt.name AS tax_name, utd.amount_due, utd.due_date, utd.status,
               tp.receipt_no
        FROM user_tax_details utd
        JOIN tax_types tt ON utd.tax_type_id = tt.id
        LEFT JOIN tax_payments tp 
            ON utd.user_id = tp.user_id AND utd.tax_type_id = tp.tax_type_id AND utd.status = 'paid'
        WHERE utd.user_id = ?
        ORDER BY utd.due_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Tax Details</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            
            background-size: cover;
        }

        .container {
            max-width: 90%;
            margin: 40px auto;
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #34495e;
            color: white;
        }

        tr:nth-child(even) td {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            color: #007BFF;
        }

        a:hover {
            color: #d35400;
        }

        button {
            padding: 10px 15px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover {
            background-color: #1c5980;
        }

        .links {
            margin-top: 20px;
            text-align: center;
        }

        .links a {
            margin: 0 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Your Tax Details</h2>

    <table>
        <tr>
            <th>Tax Name</th>
            <th>Amount Due</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= htmlspecialchars($row['tax_name']) ?></td>
                <td>₹<?= number_format($row['amount_due'], 2) ?></td>
                <td><?= htmlspecialchars($row['due_date']) ?></td>
                <td><?= ucfirst($row['status']) ?></td>
                <td>
                    <?php if ($row['status'] == 'unpaid') { ?>
                        <a href="pay_tax.php?tax_id=<?= $row['tax_id'] ?>">Pay Now</a>
                    <?php } else { ?>
                        <a href="tax_receipt.php?receipt_no=<?= $row['receipt_no'] ?>" target="_blank">Download Receipt</a>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </table>

    <div class="links">
        <a href="payment_history.php"><button>View Full Payment History</button></a>
        <a href="user_dashboard.php"><button>Back to Dashboard</button></a>
    </div>
</div>
</body>
</html>
