<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php");
    exit();
}
include 'db.php';

if (isset($_POST['upload'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $uploaded_by = $_SESSION['username'];

    $file = $_FILES['asset_file'];
    $file_name = basename($file['name']);
    $target_dir = "uploads/";
    $target_file = $target_dir . time() . "_" . $file_name;
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $allowed = ['pdf', 'docx', 'jpg', 'png'];

    if (!in_array($file_type, $allowed)) {
        echo "<p style='color:red;'>Only PDF, DOCX, JPG, and PNG files are allowed.</p>";
        exit();
    }

    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        $stmt = $conn->prepare("INSERT INTO assets (title, description, file_path, uploaded_by) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $title, $description, $target_file, $uploaded_by);
        $stmt->execute();

        echo "<p style='color:green;'>File uploaded successfully!</p>";
    } else {
        echo "<p style='color:red;'>Error uploading file.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Village Assets</title>
    <style>
        body {
            margin: 0;
            padding: 0;
           
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.95);
            max-width: 600px;
            margin: 60px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }
        form label {
            font-weight: bold;
            color: #34495e;
        }
        input[type="text"],
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-top: 6px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #27ae60;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: #1e8449;
        }
        a {
            display: inline-block;
            margin-top: 15px;
            color: #2980b9;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Upload Village Asset or Census Data</h2>
    <form action="upload_assets.php" method="POST" enctype="multipart/form-data">
        <label>Title:</label>
        <input type="text" name="title" required>

        <label>Description:</label>
        <textarea name="description" rows="4"></textarea>

        <label>Select File (PDF, DOCX, JPG, PNG):</label>
        <input type="file" name="asset_file" accept=".pdf,.docx,.jpg,.png" required>

        <input type="submit" name="upload" value="Upload">
    </form>
    <br>
    <a href="<?= ($_SESSION['role'] === 'admin') ? 'admin_dashboard.php' : 'staff_dashboard.php'; ?>">← Back to Dashboard</a>
    <br>
    <a href="view_assets.php">→ View Uploaded Assets</a>
</div>
</body>
</html>
