<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle feedback deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Confirm feedback belongs to user
    $stmt = $conn->prepare("DELETE FROM feedback WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $delete_id, $user_id);
    $stmt->execute();

    echo "<script>alert('Feedback deleted successfully!'); window.location.href='give_feedback.php';</script>";
    exit();
}

// Handle new feedback submission
if (isset($_POST['submit_feedback'])) {
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);
    $submit_date = date('Y-m-d H:i:s');
    $status = 'pending';

    $stmt = $conn->prepare("INSERT INTO feedback (user_id, title, message, submit_date, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $user_id, $title, $message, $submit_date, $status);
    $stmt->execute();

    echo "<script>alert('Feedback submitted successfully!'); window.location.href='give_feedback.php';</script>";
    exit();
}

// Fetch user feedbacks
$stmt = $conn->prepare("SELECT * FROM feedback WHERE user_id = ? ORDER BY submit_date DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$feedbacks = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Give Feedback</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

        body {
            font-family: 'Roboto', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: 
              linear-gradient(rgba(255, 255, 255, 0.85), rgba(255, 255, 255, 0.85)),
              
            background-size: cover;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 30px;
            font-weight: 700;
        }

        form {
            max-width: 600px;
            margin: 0 auto 50px auto;
        }

        label {
            font-weight: 600;
            display: block;
            margin-bottom: 8px;
            color: #34495e;
        }

        input[type="text"], textarea {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 20px;
            border: 1.8px solid #ccc;
            border-radius: 8px;
            font-size: 1em;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, textarea:focus {
            border-color: #2980b9;
            outline: none;
        }

        input[type="submit"] {
            background-color: #2980b9;
            color: white;
            font-weight: 700;
            padding: 12px 0;
            border: none;
            border-radius: 8px;
            width: 100%;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #1c5980;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
            font-size: 0.95em;
        }

        th {
            background-color: #f7f9fc;
            color: #34495e;
            font-weight: 700;
        }

        a {
            color: #2980b9;
            text-decoration: none;
            font-weight: 600;
        }

        a:hover {
            text-decoration: underline;
        }

        td a {
            margin-right: 10px;
        }

        p.no-feedback {
            text-align: center;
            font-style: italic;
            color: #7f8c8d;
        }

        .back-link {
            display: block;
            max-width: 900px;
            margin: 30px auto 40px auto;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Submit Feedback</h2>
    <form method="POST" action="">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>

        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="5" required></textarea>

        <input type="submit" name="submit_feedback" value="Submit Feedback">
    </form>

    <h2>Your Feedback History</h2>

    <?php if ($feedbacks->num_rows > 0): ?>
    <table>
        <thead>
        <tr>
            <th>Title</th>
            <th>Message</th>
            <th>Status</th>
            <th>Submitted On</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php while($row = $feedbacks->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
                <td><?= $row['submit_date'] ?></td>
                <td>
                    <?php if ($row['status'] !== 'close'): ?>
                        <a href="edit_feedback.php?feedback_id=<?= $row['id'] ?>">Edit</a> |
                    <?php endif; ?>
                    <a href="give_feedback.php?delete_id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this feedback?');">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p class="no-feedback">You have not submitted any feedback yet.</p>
    <?php endif; ?>
</div>

<div class="back-link">
    <a href="user_dashboard.php">← Back to Dashboard</a>
</div>
</body>
</html>
