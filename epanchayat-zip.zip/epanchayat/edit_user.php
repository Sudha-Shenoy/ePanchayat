<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "epanchayat");

$id = intval($_GET['id']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'];
    $conn->query("UPDATE users SET role='$role' WHERE id=$id");
    header("Location: manage_users.php");
    exit();
}

$result = $conn->query("SELECT * FROM users WHERE id=$id");
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Edit User Role</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
            
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #222;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.25);
            width: 400px;
            text-align: center;
        }

        h2 {
            color: #004085;
            margin-bottom: 25px;
            font-weight: 700;
        }

        strong {
            font-size: 1.2em;
            color: #333;
        }

        label {
            display: block;
            margin: 20px 0 8px 0;
            font-weight: 600;
            font-size: 1em;
        }

        select {
            width: 100%;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1.5px solid #ccc;
            font-size: 1em;
            transition: border-color 0.3s ease;
        }

        select:focus {
            border-color: #004085;
            outline: none;
        }

        input[type="submit"] {
            margin-top: 30px;
            width: 100%;
            padding: 12px 0;
            font-weight: 700;
            font-size: 1.1em;
            border: none;
            border-radius: 8px;
            background-color: #004085;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #002752;
        }

        a {
            display: inline-block;
            margin-top: 25px;
            color: #004085;
            font-weight: 600;
            text-decoration: none;
            font-size: 0.95em;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit User Role</h2>
        <form method="post">
            <label>Username:</label>
            <strong><?= htmlspecialchars($user['username']); ?></strong>

            <label for="role">Role:</label>
            <select id="role" name="role">
                <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>User</option>
                <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
            </select>

            <input type="submit" value="Update Role">
        </form>
        <a href="manage_users.php">← Back to Manage Users</a>
    </div>
</body>
</html>
