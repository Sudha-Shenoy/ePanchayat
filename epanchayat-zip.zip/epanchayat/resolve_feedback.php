<?php
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Resolve Feedback</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(rgba(255,255,255,0.95), rgba(255,255,255,0.95)), 
                 
      background-size: cover;
      padding: 40px;
      color: #333;
    }

    .container {
      max-width: 600px;
      margin: 50px auto;
      background: white;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      text-align: center;
    }

    h2 {
      color: #2c3e50;
    }

    .message {
      margin-top: 20px;
      font-size: 1.1em;
      color: green;
    }

    .error {
      color: red;
      font-weight: bold;
    }

    a {
      display: inline-block;
      margin-top: 20px;
      text-decoration: none;
      background-color: #2980b9;
      color: white;
      padding: 10px 18px;
      border-radius: 5px;
    }

    a:hover {
      background-color: #1c5d86;
    }
  </style>
</head>
<body>

<div class="container">
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("UPDATE feedback SET status = 'resolved' WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<h2>Feedback Marked as Resolved</h2>";
        echo "<p class='message'>The feedback record has been updated successfully.</p>";
        echo "<a href='manage_feedback.php'>Back to Feedback Management</a>";
    } else {
        echo "<h2>Error</h2>";
        echo "<p class='error'>Error updating feedback: " . $stmt->error . "</p>";
        echo "<a href='manage_feedback.php'>Back to Feedback Management</a>";
    }
} else {
    echo "<h2>Error</h2>";
    echo "<p class='error'>No feedback ID provided.</p>";
    echo "<a href='manage_feedback.php'>Back to Feedback Management</a>";
}
?>
</div>

</body>
</html>
