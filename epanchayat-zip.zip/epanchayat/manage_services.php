<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}
$conn = mysqli_connect("localhost", "root", "", "epanchayat");
$result = mysqli_query($conn, "SELECT * FROM schemes");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Manage Schemes - Admin</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');

    body {
        margin: 0;
        padding: 0;
        font-family: 'Open Sans', sans-serif;
        background:
          linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
         
        background-size: cover;
        color: #f0f0f0;
        min-height: 100vh;
    }

    .container {
        max-width: 1000px;
        margin: 40px auto;
        background: rgba(255, 255, 255, 0.95);
        padding: 30px 40px;
        border-radius: 10px;
        box-shadow: 0 15px 30px rgba(0,0,0,0.3);
        color: #333;
    }

    h2 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: 700;
        color: #2c3e50;
    }

    a.add-scheme {
        display: inline-block;
        background-color: #27ae60;
        color: white;
        padding: 10px 18px;
        border-radius: 6px;
        font-weight: 600;
        text-decoration: none;
        margin-bottom: 20px;
        transition: background-color 0.3s ease;
    }
    a.add-scheme:hover {
        background-color: #1e8449;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.95rem;
    }

    th, td {
        padding: 12px 15px;
        border: 1px solid #ddd;
        text-align: left;
        vertical-align: middle;
    }

    th {
        background-color: #34495e;
        color: #ecf0f1;
        font-weight: 600;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:hover {
        background-color: #d1f0d1;
    }

    a {
        color: #2980b9;
        font-weight: 600;
        text-decoration: none;
        margin-right: 8px;
    }
    a:hover {
        text-decoration: underline;
    }

    .back-link {
        display: inline-block;
        margin-top: 30px;
        font-weight: 600;
        color: #2980b9;
        text-decoration: none;
    }
    .back-link:hover {
        text-decoration: underline;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .container {
            margin: 20px 10px;
            padding: 20px;
        }
        table, thead, tbody, th, td, tr {
            display: block;
        }
        thead tr {
            display: none;
        }
        tr {
            margin-bottom: 15px;
            background: #fff;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        td {
            border: none;
            padding-left: 50%;
            position: relative;
            text-align: left;
            color: #34495e;
        }
        td:before {
            position: absolute;
            top: 12px;
            left: 15px;
            width: 45%;
            white-space: nowrap;
            font-weight: 700;
            color: #34495e;
        }
        td:nth-of-type(1):before { content: "ID"; }
        td:nth-of-type(2):before { content: "Name"; }
        td:nth-of-type(3):before { content: "Description"; }
        td:nth-of-type(4):before { content: "Eligibility"; }
        td:nth-of-type(5):before { content: "Status"; }
        td:nth-of-type(6):before { content: "Actions"; }
    }
</style>
</head>
<body>
<div class="container">
    <h2>Manage Schemes & Services</h2>
    <a href="add_scheme.php" class="add-scheme">+ Add New Scheme</a>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Eligibility</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= htmlspecialchars($row['id']); ?></td>
                <td><?= htmlspecialchars($row['name']); ?></td>
                <td><?= htmlspecialchars($row['description']); ?></td>
                <td><?= htmlspecialchars($row['eligibility']); ?></td>
                <td><?= ucfirst(htmlspecialchars($row['status'])); ?></td>
                <td>
                    <a href="edit_scheme.php?id=<?= $row['id']; ?>">Edit</a> |
                    <a href="delete_scheme.php?id=<?= $row['id']; ?>" onclick="return confirm('Delete this scheme?');">Delete</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

    <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>
</div>
</body>
</html>
