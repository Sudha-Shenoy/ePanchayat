<?php
include 'db.php';

$users = $conn->query("SELECT id, username FROM users WHERE role = 'user'");
$taxes = $conn->query("SELECT id, name FROM tax_types");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add User Payment</title>
    <style>
        body {
            font-family: Arial;
            
            background-size: cover;
            margin: 0;
        }
        .container {
            background: rgba(255,255,255,0.95);
            max-width: 600px;
            margin: 60px auto;
            padding: 30px;
            border-radius: 10px;
        }
        h2 {
            text-align: center;
        }
        label {
            display: block;
            margin-top: 15px;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
        }
        input[type="submit"] {
            margin-top: 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Add User Tax Payment</h2>
    <form action="add_user_payment_process.php" method="POST">
        <label>User:</label>
        <select name="user_id" required>
            <?php while ($u = $users->fetch_assoc()) { ?>
                <option value="<?= $u['id'] ?>"><?= $u['username'] ?></option>
            <?php } ?>
        </select>

        <label>Tax Type:</label>
        <select name="tax_type_id" required>
            <?php while ($t = $taxes->fetch_assoc()) { ?>
                <option value="<?= $t['id'] ?>"><?= $t['name'] ?></option>
            <?php } ?>
        </select>

        <label>Amount Paid (₹):</label>
        <input type="number" name="amount_paid" required>

        <label>Payment Method:</label>
        <select name="method" required>
            <option value="cash">Cash</option>
            <option value="online">Online</option>
        </select>

        <input type="submit" value="Submit Payment">
    </form>
</div>
</body>
</html>
