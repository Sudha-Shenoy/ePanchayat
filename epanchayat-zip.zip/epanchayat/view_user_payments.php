<?php
session_start();
include 'db.php';

// Optional: Check if admin or staff
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff') {
    die("Access denied.");
}

$sql = "SELECT tp.*, tt.name AS tax_name, u.username 
        FROM tax_payments tp
        JOIN tax_types tt ON tp.tax_type_id = tt.id
        JOIN users u ON tp.user_id = u.id
        ORDER BY tp.payment_date DESC";

$result = $conn->query($sql);
?>

<h2>All User Tax Payments</h2>
<table border="1">
    <tr>
        <th>Receipt No</th>
        <th>User</th>
        <th>Tax Type</th>
        <th>Amount Paid</th>
        <th>Payment Date</th>
        <th>Method</th>
        <th>Receipt</th>
    </tr>

<?php while($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?= $row['receipt_no'] ?></td>
        <td><?= $row['username'] ?></td>
        <td><?= $row['tax_name'] ?></td>
        <td>₹<?= $row['amount_paid'] ?></td>
        <td><?= $row['payment_date'] ?></td>
        <td><?= $row['method'] ?></td>
       <td><a href="admin_tax_receipt.php?receipt_no=<?= $row['receipt_no'] ?>" target="_blank">View Receipt</a></td>

    </tr>
<?php } ?>
</table>
<br>
<a href="add_user_payment.php" style="padding: 10px 10px; background-color: green; color: white; text-decoration: none; border-radius: 1px;">Add New Payment</a>
<br>
<br><a href="<?= ($_SESSION['role'] === 'admin') ? 'admin_dashboard.php' : 'staff_dashboard.php'; ?>">← Back to Dashboard</a>
