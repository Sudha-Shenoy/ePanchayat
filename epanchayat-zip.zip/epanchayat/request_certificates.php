<?php
// Include database connection
include('db.php');
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle certificate request form submission
if (isset($_POST['submit_request'])) {
    $certificate_type = $_POST['certificate_type'];
    $purpose = $_POST['purpose'];
    $file = $_FILES['document'];

    if ($file['error'] == 0) {
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $file_path = 'uploads/' . $file_name;
        move_uploaded_file($file_tmp, $file_path);

        $query = $conn->prepare("INSERT INTO certificate_requests (user_id, certificate_type, purpose, request_date, status) VALUES (?, ?, ?, NOW(), ?)");
        $status = 'Pending';
        $query->bind_param("isss", $user_id, $certificate_type, $purpose, $status);
        $query->execute();

        $doc_type = 'Certificate';
        $query_doc = $conn->prepare("INSERT INTO submitted_documents (user_id, doc_type, file_path, status, submitted_at) VALUES (?, ?, ?, ?, NOW())");
        $query_doc->bind_param("isss", $user_id, $doc_type, $file_path, $status);
        $query_doc->execute();

        echo "<p class='success'>Certificate request submitted successfully.</p>";
    }
}

// Fetch past requests
$query_requests = $conn->prepare("SELECT * FROM certificate_requests WHERE user_id = ?");
$query_requests->bind_param("i", $user_id);
$query_requests->execute();
$result_requests = $query_requests->get_result();

// Handle delete
if (isset($_POST['delete_request'])) {
    $request_id = $_POST['delete_request_id'];

    $query_delete_req = $conn->prepare("DELETE FROM certificate_requests WHERE id = ?");
    $query_delete_req->bind_param("i", $request_id);
    $query_delete_req->execute();

    $query_delete_doc = $conn->prepare("DELETE FROM submitted_documents WHERE id = ?");
    $query_delete_doc->bind_param("i", $request_id);
    $query_delete_doc->execute();

    echo "<p class='success'>Certificate request deleted successfully.</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Request Certificate</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 40px;
      background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),
                 
      background-size: cover;
      color: #333;
    }

    h1, h2 {
      text-align: center;
      color: #2c3e50;
    }

    form, table {
      max-width: 700px;
      margin: 20px auto;
      background: #fff;
      padding: 25px;
      border-radius: 8px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    }

    label {
      display: block;
      margin-top: 10px;
      font-weight: bold;
    }

    input[type="text"], input[type="file"], textarea {
      width: 100%;
      padding: 8px;
      margin-top: 6px;
      margin-bottom: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    button {
      background-color: #2980b9;
      color: white;
      padding: 10px 18px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    button:hover {
      background-color:#1c5d86;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 25px;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 10px;
      text-align: center;
    }

    th {
      background-color: #34495e;
      color: white;
    }

    td form {
      display: inline;
    }

    a {
      color: #2980b9;
      text-decoration: none;
      margin-right: 8px;
    }

    a:hover {
      text-decoration: underline;
    }

    .success {
      text-align: center;
      color: green;
      font-weight: bold;
    }

    .back-link {

      text-align: center;
      margin-top: 20px;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <h1>Request a Certificate</h1>

  <form method="POST" enctype="multipart/form-data">
    <label for="certificate_type">Certificate Type:</label>
    <input type="text" name="certificate_type" required>

    <label for="purpose">Purpose:</label>
    <input type="text" name="purpose" required>

    <label for="document">Upload Document (if required):</label>
    <input type="file" name="document" required>

    <button type="submit" name="submit_request">Submit Request</button>
  </form>

  <h2>Your Past Certificate Requests</h2>
  <table>
    <tr>
      <th>Certificate Type</th>
      <th>Purpose</th>
      <th>Status</th>
      <th>Actions</th>
    </tr>
    <?php while ($row = $result_requests->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['certificate_type']) ?></td>
        <td><?= htmlspecialchars($row['purpose']) ?></td>
        <td><?= htmlspecialchars($row['status']) ?></td>
        <td>
          <a href="edit_certificate.php?request_id=<?= $row['id'] ?>">Edit</a>
          <form method="POST" style="display:inline;">
            <input type="hidden" name="delete_request_id" value="<?= $row['id'] ?>">
            <button type="submit" name="delete_request" onclick="return confirm('Delete this request?')">Delete</button>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>

  <a class="back-link" href="user_dashboard.php">← Back to Dashboard</a>

</body>
</html>
