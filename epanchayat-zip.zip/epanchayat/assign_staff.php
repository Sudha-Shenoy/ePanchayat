<?php
session_start();
include 'db.php';

if ($_SESSION['role'] !== 'admin') {
    die("Access denied.");
}

if (isset($_POST['application_id']) && isset($_POST['staff_id'])) {
    $application_id = $_POST['application_id'];
    $staff_id = $_POST['staff_id'];

    $stmt = $conn->prepare("UPDATE scheme_applications SET assigned_to = ? WHERE id = ?");
    $stmt->bind_param("ii", $staff_id, $application_id);

    if ($stmt->execute()) {
        header("Location: view_scheme_applications.php");
        exit();
    } else {
        echo "Error updating assignment.";
    }
    exit();
}

// Fetch application and staff info for the form
$application_id = $_GET['id'] ?? null;

if (!$application_id) {
    die("No application selected.");
}

$app_stmt = $conn->prepare("SELECT id, scheme_name FROM scheme_applications WHERE id = ?");
$app_stmt->bind_param("i", $application_id);
$app_stmt->execute();
$app_result = $app_stmt->get_result();
$application = $app_result->fetch_assoc();

$staff_stmt = $conn->query("SELECT id, name FROM staff WHERE status = 'active'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign Staff</title>
    <style>
        body {
            
            background-size: cover;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 80px auto;
            background-color: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        form {
            margin-top: 30px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
        }

        select, input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        input[type="submit"] {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }

        a {
            display: inline-block;
            margin-top: 10px;
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Assign Staff to Application</h2>

    <p><strong>Scheme Application:</strong> <?= htmlspecialchars($application['scheme_name']) ?></p>

    <form method="POST">
        <input type="hidden" name="application_id" value="<?= $application['id'] ?>">

        <label for="staff_id">Select Staff Member:</label>
        <select name="staff_id" required>
            <option value="">-- Choose Staff --</option>
            <?php while ($staff = $staff_stmt->fetch_assoc()): ?>
                <option value="<?= $staff['id'] ?>"><?= htmlspecialchars($staff['name']) ?></option>
            <?php endwhile; ?>
        </select>

        <input type="submit" value="Assign Staff">
    </form>

    <a href="view_scheme_applications.php">← Back to Applications</a>
</div>

</body>
</html>
