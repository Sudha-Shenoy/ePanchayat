<?php
session_start();
require 'db.php';

if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $app_id = $_POST['id'];
    $details = trim($_POST['details']);
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE scheme_applications SET details = ? WHERE id = ? AND user_id = ? AND status = 'pending'");
    $stmt->bind_param("sii", $details, $app_id, $user_id);

    if ($stmt->execute()) {
        header("Location: apply_schemes.php");
        exit();
    } else {
        $error = $stmt->error;
    }
} else {
    $error = "Invalid request.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Application Error</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            
            background-size: cover;
        }
        .error-container {
            max-width: 500px;
            margin: 100px auto;
            background-color: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 6px 18px rgba(0,0,0,0.3);
            text-align: center;
        }
        h2 {
            color: #c0392b;
        }
        p {
            color: #333;
        }
        a {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 15px;
            background-color: #2980b9;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background-color: #1c5980;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h2>Error Updating Application</h2>
        <p><?= htmlspecialchars($error) ?></p>
        <a href="apply_schemes.php">Back to Applications</a>
    </div>
</body>
</html>
