<?php
include 'db.php';

$message = '';
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM reports WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header('Location: manage_reports.php');
        exit();
    } else {
        $message = "Error: " . $stmt->error;
    }
} else {
    $message = "No report ID provided.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Delete Report</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap');

  body {
    margin: 0;
    padding: 0;
    font-family: 'Montserrat', sans-serif;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background:
      linear-gradient(135deg, #2c3e50 0%, #000000 100%),
      url('https://www.transparenttextures.com/patterns/noise.png');
    background-repeat: repeat;
    color: #f0f0f0;
  }

  .message-box {
    background: rgba(40, 44, 52, 0.9);
    padding: 40px 50px;
    border-radius: 12px;
    box-shadow:
      0 8px 24px rgba(0, 0, 0, 0.8),
      inset 0 0 10px rgba(255, 255, 255, 0.05);
    max-width: 400px;
    text-align: center;
    border: 2px solid #3f51b5;
  }

  h2 {
    font-weight: 700;
    font-size: 1.8rem;
    margin-bottom: 20px;
    color: #82aaff;
    text-shadow: 0 0 8px #5c6bc0;
  }

  a {
    color: #82aaff;
    text-decoration: none;
    font-weight: 600;
    font-size: 1.1rem;
    margin-top: 20px;
    display: inline-block;
  }
  a:hover {
    text-decoration: underline;
  }
</style>
</head>
<body>
  <div class="message-box">
    <h2><?= htmlspecialchars($message) ?: 'Processing...' ?></h2>
    <a href="manage_reports.php">Back to Reports</a>
  </div>
</body>
</html>
