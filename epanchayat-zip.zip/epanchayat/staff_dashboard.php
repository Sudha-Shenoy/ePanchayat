
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Dashboard</title>
    <style>
        body {
            background: url('assets/staff-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 20px;
        }
        .content-wrapper {
            background: rgba(0, 0, 0, 0.6);
            padding: 20px;
            border-radius: 10px;
            max-width: 800px;
            margin: 40px auto;
        }
    </style>
</head>
<body>
    <div class="content-wrapper">
      <?php
session_start();
if ($_SESSION['role'] !== 'staff') {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Staff Dashboard</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="staff-dashboard">
  <div class="container">
    <h1>Welcome Staff: <?php echo $_SESSION['username']; ?></h1>
    <ul>
        <li><a href="view_scheme_applications.php">Process Scheme Applications</a></li>
        <li><a href="manage_complaints.php">Manage Complaints</a></li>
        <li><a href="upload_assets.php">Upload Village Asset Data</a></li>
        <li><a href="issue_certificate.php">Verify Documents & Issue Certificates</a></li>
        <li><a href="publish_notice.php">Publish Notices</a></li>
        <li><a href="view_user_payments.php">Handle Tax Payments</a></li>
        <li><a href="manage_feedback.php">Manage Feedback</a></li>
        <li><a href="manage_reports.php">Manage Reports</a></li>
    </ul>
    <a href="logout.php" style="color: red;">Logout</a>
  </div>
</body>
</html>
    </div>
</body>
</html>
