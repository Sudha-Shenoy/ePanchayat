<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="register-page">
  <div class="container">
    <h2>Register</h2>
    <form method="POST" action="">
      <input type="text" name="username" placeholder="Username" required><br>
      <input type="password" name="password" placeholder="Password" required><br>

      <select name="role" id="role" required onchange="toggleSpecialCode()">
        <option value="">Select Role</option>
        <option value="user">User</option>
        <option value="admin">Admin</option>
        <option value="staff">Staff</option>
      </select><br>

      <input type="text" name="village" placeholder="Enter your village name" required><br>
      <input type="text" name="mobile" placeholder="Enter your mobile number" required><br>
      <input type="text" name="aadhaar" placeholder="Enter your Aadhaar number" required><br>

      <div id="special-code-container" style="display:none;">
        <input type="text" name="special_code" placeholder="Enter special code for Admin/Staff"><br>
      </div>

      <br>
      <input type="submit" name="register" value="Register">
    </form>
<a href="index.php">Back</a>
    <?php
    if (isset($_POST['register'])) {
      $user = trim($_POST['username']);
      $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
      $role = $_POST['role'];
      $village = strtolower(trim($_POST['village']));
      $mobile = trim($_POST['mobile']);
      $aadhaar = trim($_POST['aadhaar']);
      $special_code = isset($_POST['special_code']) ? trim($_POST['special_code']) : null;

      // Validation
      if ($village !== 'abc') {
        echo "<p style='color:red;'>Only residents of abc village can register.</p>";
      } elseif (!preg_match('/^\d{10}$/', $mobile)) {
        echo "<p style='color:red;'>Invalid mobile number. Must be 10 digits.</p>";
      } elseif (!preg_match('/^\d{12}$/', $aadhaar)) {
        echo "<p style='color:red;'>Invalid Aadhaar number. Must be 12 digits.</p>";
      } elseif (($role == 'admin' || $role == 'staff')) {
        // Check special code in DB
        $stmt = $conn->prepare("SELECT * FROM special_codes WHERE role = ? AND code = ?");
        $stmt->bind_param("ss", $role, $special_code);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
          echo "<p style='color:red;'>Invalid special code for $role.</p>";
          $stmt->close();
        } else {
          $stmt->close();
          // Insert user
          $stmt = $conn->prepare("INSERT INTO users (username, password, role, village, mobile, aadhaar, special_code) VALUES (?, ?, ?, ?, ?, ?, ?)");
          $stmt->bind_param("sssssss", $user, $pass, $role, $village, $mobile, $aadhaar, $special_code);
          if ($stmt->execute()) {
            echo "<p style='color:green;'>Registered successfully! <a href='login.php'>Login</a></p>";
          } else {
            echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
          }
          $stmt->close();
        }
      } else {
        // For regular users (no special code needed)
        $stmt = $conn->prepare("INSERT INTO users (username, password, role, village, mobile, aadhaar, special_code) VALUES (?, ?, ?, ?, ?, ?, NULL)");
        $stmt->bind_param("ssssss", $user, $pass, $role, $village, $mobile, $aadhaar);
        if ($stmt->execute()) {
          echo "<p style='color:green;'>Registered successfully! <a href='login.php'>Login</a></p>";
        } else {
          echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
      }
    }
    ?>
  </div>


  <script>
  function toggleSpecialCode() {
    const role = document.getElementById('role').value;
    const codeContainer = document.getElementById('special-code-container');
    codeContainer.style.display = (role === 'admin' || role === 'staff') ? 'block' : 'none';
  }
  </script>

</body>
</html>
