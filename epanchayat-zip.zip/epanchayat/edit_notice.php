<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM notices WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $notice = $result->fetch_assoc();

    if (!$notice) {
        die("Notice not found.");
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $status = $_POST['status'];

        $updateQuery = "UPDATE notices SET title = ?, description = ?, status = ? WHERE id = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("sssi", $title, $description, $status, $id);

        if ($updateStmt->execute()) {
            header('Location: publish_notice.php');
            exit();
        } else {
            echo "Error: " . $updateStmt->error;
        }
    }
} else {
    die("No notice ID provided.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit Notice</title>
<style>
  body {
    margin: 0; padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #333;
  }
  .container {
    background: rgba(255, 255, 255, 0.95);
    padding: 30px 40px;
    border-radius: 10px;
    width: 450px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.25);
  }
  h1 {
    margin-bottom: 25px;
    text-align: center;
    color: #007acc;
  }
  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
  }
  input[type="text"], textarea, select {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    box-sizing: border-box;
    resize: vertical;
  }
  button {
    width: 100%;
    padding: 12px;
    background-color: #007acc;
    border: none;
    border-radius: 6px;
    color: white;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  button:hover {
    background-color: #005fa3;
  }
  a {
    display: block;
    margin-top: 15px;
    text-align: center;
    color: #007acc;
    text-decoration: none;
    font-weight: 600;
  }
  a:hover {
    text-decoration: underline;
  }
</style>
</head>
<body>
  <div class="container">
    <h1>Edit Notice</h1>
    <form method="post">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($notice['title']); ?>" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="5" required><?php echo htmlspecialchars($notice['description']); ?></textarea>

        <label for="status">Status:</label>
        <select id="status" name="status">
            <option value="active" <?php echo $notice['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
            <option value="inactive" <?php echo $notice['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
        </select>

        <button type="submit">Update Notice</button>
    </form>
    <a href="publish_notice.php">← Back to Notices</a>
  </div>
</body>
</html>
