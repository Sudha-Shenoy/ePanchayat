<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php");
    exit();
}
// Database connection
include 'db.php';

$query = "SELECT * FROM notices ORDER BY publish_date DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Notices</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

    body {
      margin: 0;
      font-family: 'Roboto', sans-serif;
      background: 
        linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),
        
      background-size: cover;
      color: #333;
      padding: 40px;
    }

    h1 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    a {
      text-decoration: none;
      color: #fff;
      background: #2980b9;
      padding: 10px 15px;
      border-radius: 6px;
      font-size: 0.95rem;
      transition: background-color 0.3s ease;
      margin-bottom: 20px;
      display: inline-block;
    }

    a:hover {
      background-color: #1c5d86;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    th, td {
      padding: 12px 15px;
      border: 1px solid #ddd;
      text-align: left;
    }

    th {
      background-color: #34495e;
      color: #fff;
    }

    td a {
      color: #2980b9;
      background: none;
      padding: 0;
    }

    td a:hover {
      text-decoration: underline;
    }

    .dashboard-link {
      margin-top: 25px;
      display: inline-block;
    }
  </style>
</head>
<body>

  <h1>Manage Notices</h1>
  <a href="add_notice.php">➕ Add New Notice</a>

  <table>
    <tr>
      <th>Title</th>
      <th>Description</th>
      <th>Publish Date</th>
      <th>Status</th>
      <th>Actions</th>
    </tr>
    <?php while($notice = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($notice['title']) ?></td>
        <td><?= htmlspecialchars($notice['description']) ?></td>
        <td><?= $notice['publish_date'] ?></td>
        <td><?= ucfirst($notice['status']) ?></td>
        <td>
          <a href="edit_notice.php?id=<?= $notice['id'] ?>">Edit</a> |
          <a href="delete_notice.php?id=<?= $notice['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>

  <a class="dashboard-link" href="<?= ($_SESSION['role'] === 'admin') ? 'admin_dashboard.php' : 'staff_dashboard.php'; ?>">← Back to Dashboard</a>

</body>
</html>
