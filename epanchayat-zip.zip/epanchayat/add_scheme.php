<?php
$conn = mysqli_connect("localhost", "root", "", "epanchayat");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $eligibility = $_POST['eligibility'];
    $last_date = $_POST['last_date'];
    $status = $_POST['status'];

    $sql = "INSERT INTO schemes (name, description, eligibility, last_date, status)
            VALUES ('$name', '$description', '$eligibility', '$last_date', '$status')";
    mysqli_query($conn, $sql);
    header("Location: manage_services.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Scheme</title>
    <style>
        body {
            
            background-size: cover;
            font-family: Arial;
            margin: 0;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            width: 600px;
            margin: 60px auto;
            padding: 30px;
            border-radius: 10px;
        }
        h2 {
            text-align: center;
        }
        label {
            display: block;
            margin-top: 15px;
        }
        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
        }
        input[type="submit"] {
            margin-top: 20px;
            background: #007BFF;
            color: white;
            border: none;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Add New Government Scheme</h2>
    <form method="post">
        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Description:</label>
        <textarea name="description" required></textarea>

        <label>Eligibility:</label>
        <textarea name="eligibility" required></textarea>

        <label>Last Date:</label>
        <input type="date" name="last_date">

        <label>Status:</label>
        <select name="status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
        </select>

        <input type="submit" value="Add Scheme">
    </form>
</div>
</body>
<a href="manage_services.php">Back</a>
</html>
