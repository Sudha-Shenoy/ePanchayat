<?php
session_start();
require 'db.php';

if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$complaint_id = $_GET['id'] ?? 0;

// Fetch complaint
$stmt = $conn->prepare("SELECT subject, message FROM complaints WHERE id = ? AND user_id = ? AND status = 'pending'");
$stmt->bind_param("ii", $complaint_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Invalid or non-editable complaint.";
    exit();
}

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit Complaint</title>
<style>
  body {
    margin: 0; padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
   
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #333;
  }
  .container {
    background: rgba(255,255,255,0.95);
    padding: 30px 40px;
    border-radius: 10px;
    width: 400px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
  }
  h2 {
    margin-bottom: 25px;
    text-align: center;
    color: #007acc;
  }
  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
  }
  input[type="text"], textarea {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    box-sizing: border-box;
    resize: vertical;
  }
  input[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #007acc;
    border: none;
    border-radius: 6px;
    color: white;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  input[type="submit"]:hover {
    background-color: #005fa3;
  }
  a {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: #007acc;
    text-decoration: none;
    font-weight: 600;
  }
  a:hover {
    text-decoration: underline;
  }
</style>
</head>
<body>
<div class="container">
    <h2>Edit Complaint</h2>
    <form method="post" action="update_complaint.php">
        <input type="hidden" name="id" value="<?php echo $complaint_id; ?>">

        <label for="subject">Subject:</label>
        <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($row['subject']); ?>" required>

        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="5" required><?php echo htmlspecialchars($row['message']); ?></textarea>

        <input type="submit" value="Update Complaint">
    </form>
    <a href="complaints.php">← Back</a>
</div>
</body>
</html>
