<?php
include 'db.php';

if (!isset($_GET['receipt_no'])) {
    die("Receipt number not provided.");
}

$receipt_no = $_GET['receipt_no'];

$sql = "SELECT tp.*, tt.name AS tax_name, u.username, u.mobile, u.aadhaar, u.village
        FROM tax_payments tp
        JOIN tax_types tt ON tp.tax_type_id = tt.id
        JOIN users u ON tp.user_id = u.id
        WHERE tp.receipt_no = ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Query preparation failed: " . $conn->error);
}
$stmt->bind_param("s", $receipt_no);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Receipt not found.");
}

$receipt = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tax Payment Receipt</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            
            background-size: cover;
            margin: 0;
            padding: 40px;
        }
        .receipt-container {
            background: rgba(255, 255, 255, 0.95);
            max-width: 700px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.3);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2d572c;
        }
        .section {
            margin-bottom: 20px;
        }
        .line {
            border-top: 1px dashed #666;
            margin: 20px 0;
        }
        .section h4 {
            margin-bottom: 10px;
            color: #333;
            text-decoration: underline;
        }
        p {
            margin: 5px 0;
            font-size: 16px;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            background: #007BFF;
            color: #fff;
            padding: 10px 16px;
            border-radius: 5px;
        }
        .back-link:hover {
            background-color: #0056b3;
        }
        .thank-you {
            text-align: center;
            font-weight: bold;
            font-size: 18px;
            margin-top: 30px;
            color: #444;
        }
    </style>
</head>
<body onload="window.print()">
    <div class="receipt-container">
        <h2>ePanchayat - Tax Payment Receipt</h2>
        <div class="line"></div>

        <div class="section">
            <p><strong>Receipt No:</strong> <?= $receipt['receipt_no'] ?></p>
            <p><strong>Payment Date:</strong> <?= $receipt['payment_date'] ?></p>
        </div>

        <div class="line"></div>

        <div class="section">
            <h4>User Information</h4>
            <p><strong>Name:</strong> <?= $receipt['username'] ?></p>
            <p><strong>Mobile:</strong> <?= $receipt['mobile'] ?></p>
            <p><strong>Aadhaar:</strong> <?= $receipt['aadhaar'] ?></p>
            <p><strong>Village:</strong> <?= $receipt['village'] ?></p>
        </div>

        <div class="line"></div>

        <div class="section">
            <h4>Payment Details</h4>
            <p><strong>Tax Type:</strong> <?= $receipt['tax_name'] ?></p>
            <p><strong>Amount Paid:</strong> ₹<?= number_format($receipt['amount_paid'], 2) ?></p>
            <p><strong>Method:</strong> <?= ucfirst($receipt['method']) ?></p>
        </div>

        <div class="line"></div>

        <p class="thank-you">Thank you for collecting the payment!</p>
    </div>

    <div style="text-align: center;">
        <a class="back-link" href="view_user_payments.php">Back</a>
    </div>
</body>
</html>
