<?php
session_start();
include 'db.php';

$user_id = $_SESSION['user_id'];

$sql = "SELECT tp.id, tt.name AS tax_name, tp.amount_paid, tp.payment_date, tp.method, tp.receipt_no
        FROM tax_payments tp
        JOIN tax_types tt ON tp.tax_type_id = tt.id
        WHERE tp.user_id = ?
        ORDER BY tp.payment_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment History</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

        body {
            margin: 0;
            padding: 0;
            font-family: 'Montserrat', sans-serif;
            background:
                linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),
                
            background-size: cover;
        }

        .container {
            max-width: 1000px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px 15px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #2980b9;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        a {
            text-decoration: none;
            color: #3498db;
            font-weight: bold;
        }

        a:hover {
            color: #1c5980;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Payment History</h2>
        <table>
            <tr>
                <th>Tax Type</th>
                <th>Amount Paid</th>
                <th>Payment Date</th>
                <th>Method</th>
                <th>Receipt No</th>
                <th>Download</th>
            </tr>

            <?php while($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= htmlspecialchars($row['tax_name']) ?></td>
                <td>₹<?= number_format($row['amount_paid'], 2) ?></td>
                <td><?= htmlspecialchars($row['payment_date']) ?></td>
                <td><?= htmlspecialchars($row['method']) ?></td>
                <td><?= htmlspecialchars($row['receipt_no']) ?></td>
                <td><a href="tax_receipt.php?receipt_no=<?= urlencode($row['receipt_no']) ?>" target="_blank">Download</a></td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
